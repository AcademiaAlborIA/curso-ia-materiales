from pathlib import Path
import json,hashlib
from laboratorio_datos import fit,evaluate
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'resultados.json').read_text(encoding='utf-8'))
assert len(r['initial'])==len(r['varied'])==len(r['test'])==12
for group in ['initial','varied','test']:
 assert sum(x['label']=='Circulo' for x in r[group])==6
 for row in r[group]:assert hashlib.sha256((ROOT/row['file']).read_bytes()).hexdigest()==row['sha256']
assert not {x['sha256'] for x in r['initial']+r['varied']}&{x['sha256'] for x in r['test']}
before=fit(r['initial']);after=fit(r['varied'])
assert before==r['before']['model'] and after==r['after']['model']
assert before['feature']=='rojo_del_fondo' and after['feature']=='ocupacion_de_la_figura'
assert evaluate(before,r['test'])['correct']==6
assert evaluate(after,r['test'])['correct']==12
findings=r['audit_findings'];assert findings['exact_duplicate_rows']==[[0,1]]
assert findings['missing_label_rows']==[2] and findings['label_to_review_rows']==[3] and findings['missing_file_rows']==[4]
assert r['imbalance']['always_legitimate_correct']==90 and r['imbalance']['spam_detected']==0
print('OK: imágenes, separación, reglas, resultados y casos de auditoría verificados.')
