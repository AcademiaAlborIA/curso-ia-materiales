"""Laboratorio didáctico: mismo algoritmo, distinta cobertura de los datos."""
from pathlib import Path
from PIL import Image,ImageDraw
import json,random,hashlib
ROOT=Path(__file__).resolve().parent
BACKGROUNDS={'turquesa':(35,190,185),'amarillo':(240,190,55)}
FEATURES=['rojo_del_fondo','ocupacion_de_la_figura']
def make_image(folder,name,label,bg,rng):
 path=ROOT/'datos'/folder/(name+'.png');path.parent.mkdir(parents=True,exist_ok=True)
 im=Image.new('RGB',(224,224),BACKGROUNDS[bg]);d=ImageDraw.Draw(im);size=rng.randint(85,145);x=rng.randint(20,195-size);y=rng.randint(20,195-size)
 (d.ellipse if label=='Circulo' else d.rectangle)((x,y,x+size,y+size),fill=(35,45,60));im.save(path)
 return {'file':str(path.relative_to(ROOT)),'label':label,'background':bg,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
def features(record):
 im=Image.open(ROOT/record['file']).convert('RGB');bg=im.getpixel((0,0));pts=[(x,y) for y in range(im.height) for x in range(im.width) if im.getpixel((x,y))!=bg]
 xs=[x for x,y in pts];ys=[y for x,y in pts];area=(max(xs)-min(xs)+1)*(max(ys)-min(ys)+1)
 return [bg[0]/255,len(pts)/area]
def fit(rows):
 x=[features(row) for row in rows];labels=[r['label'] for r in rows];best=None
 for j,name in enumerate(FEATURES):
  values=sorted(set(row[j] for row in x));thresholds=[(a+b)/2 for a,b in zip(values,values[1:])]
  for t in thresholds:
   left=[labels[n] for n,r in enumerate(x) if r[j]<=t];right=[labels[n] for n,r in enumerate(x) if r[j]>t]
   if not left or not right:continue
   majority=lambda a:sorted(set(a),key=lambda label:(-a.count(label),label))[0]
   lo,hi=majority(left),majority(right);errors=sum((lo if row[j]<=t else hi)!=label for row,label in zip(x,labels))
   if best is None or errors<best['errors']:best={'feature':name,'index':j,'threshold':t,'left':lo,'right':hi,'errors':errors}
 return best
def evaluate(model,rows):
 cases=[]
 for row in rows:
  value=features(row)[model['index']];pred=model['left'] if value<=model['threshold'] else model['right'];cases.append({**row,'predicted':pred,'correct':pred==row['label']})
 return {'correct':sum(r['correct'] for r in cases),'total':len(cases),'cases':cases}
def run():
 rng=random.Random(4104);initial=[];varied=[];test=[]
 for label in ['Circulo','Cuadrado']:
  for n in range(6):initial.append(make_image('antes',f'{label}-{n+1:02}',label,'turquesa' if label=='Circulo' else 'amarillo',rng))
  for bg in BACKGROUNDS:
   for n in range(3):varied.append(make_image('despues',f'{label}-{bg}-{n+1:02}',label,bg,rng));test.append(make_image('prueba',f'{label}-{bg}-{n+1:02}',label,bg,rng))
 before=fit(initial);after=fit(varied)
 # Deliberately damaged records for auditing; don't silently infer their labels.
 audit=[dict(varied[0]),dict(varied[0]),{**varied[1],'label':None},{**varied[2],'label':'Cuadrado'},{'file':'datos/no-existe.png','label':'Circulo','background':'turquesa'}]
 groups={}
 for n,row in enumerate(audit):groups.setdefault((row['file'],row.get('label')),[]).append(n)
 truth={r['file']:r['label'] for r in varied}
 findings={'exact_duplicate_rows':[g for g in groups.values() if len(g)>1],'missing_label_rows':[n for n,r in enumerate(audit) if not r.get('label')],'label_to_review_rows':[n for n,r in enumerate(audit) if r.get('label') and r['file'] in truth and r['label']!=truth[r['file']]],'missing_file_rows':[n for n,r in enumerate(audit) if not (ROOT/r['file']).exists()],'note':'La etiqueta de la fila 3 se contrasta con la figura original y la referencia del generador, no se adivina mediante el clasificador.'}
 assert not {r['sha256'] for r in initial+varied}&{r['sha256'] for r in test}
 result={'initial':initial,'varied':varied,'test':test,'before':{'model':before,'training':evaluate(before,initial),'test':evaluate(before,test)},'after':{'model':after,'training':evaluate(after,varied),'test':evaluate(after,test)},'audit_rows':audit,'audit_findings':findings,'imbalance':{'total':100,'legitimate':90,'spam':10,'always_legitimate_correct':90,'spam_detected':0},'notes':['Dibujos sintéticos y clasificador de un único corte; no es Teachable Machine.','Ambas versiones usan 12 ejemplos y el mismo algoritmo. El desempate entre reglas con igual error prioriza la característica del fondo.','Se mide un conjunto didáctico de 12 imágenes; no se garantiza generalización.','El conjunto de prueba se usa aquí para ilustrar el diagnóstico. Tras elegir cambios, una evaluación final debe reservar otros ejemplos nuevos.']}
 (ROOT/'resultados.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print('Antes:',before['feature'],'entrenamiento',result['before']['training']['correct'],'/12; prueba',result['before']['test']['correct'],'/12')
 print('Después:',after['feature'],'entrenamiento',result['after']['training']['correct'],'/12; prueba',result['after']['test']['correct'],'/12')
 return result
if __name__=='__main__':run()
