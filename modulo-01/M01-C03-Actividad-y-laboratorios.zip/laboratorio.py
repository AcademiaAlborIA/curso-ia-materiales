"""Tres experimentos didácticos reproducibles. Solo utiliza la biblioteca estándar."""
from pathlib import Path
import math,random,json,statistics
ROOT=Path(__file__).resolve().parent

def supervised():
 train=[(0,0,0),(0,1,0),(1,0,0),(1,1,0),(0,2,0),(2,0,0),(2,2,1),(3,2,1),(2,3,1),(3,3,1),(1,3,1),(3,1,1)]
 test=[(0,3,0),(3,0,1),(4,3,1),(3,4,1),(0,4,1),(4,0,1)]
 def predict(x,y):
  nearest=sorted(enumerate(train),key=lambda item:((item[1][0]-x)**2+(item[1][1]-y)**2,item[0]))[:3]
  return int(sum(row[2] for _,row in nearest)>=2)
 results=[{'x':x,'y':y,'expected':label,'predicted':predict(x,y)} for x,y,label in test]
 return {'algorithm':'3 vecinos más cercanos; desempate estable por orden','features':['enlaces','palabras_urgentes'],'labels':['Legítimo','Spam'],'train':train,'test':results,'correct':sum(r['expected']==r['predicted'] for r in results),'total':len(results),'note':'Datos inventados y conteos simplificados. Los seis casos de prueba tienen coordenadas distintas a las de entrenamiento; no son mensajes reales. No es un filtro listo para producción.'}

def clustering():
 data=[(1,12),(2,18),(1,22),(3,15),(2,25),(3,21),(8,18),(9,22),(10,15),(11,25),(9,28),(12,20),(3,85),(4,100),(5,90),(4,110),(6,105),(5,120)]
 means=[statistics.mean(row[j] for row in data) for j in range(2)];std=[statistics.pstdev(row[j] for row in data) for j in range(2)]
 z=[[(row[j]-means[j])/std[j] for j in range(2)] for row in data];centers=[z[0][:],z[6][:],z[12][:]];history=[];last=None
 for iteration in range(20):
  labels=[min(range(3),key=lambda k:sum((row[j]-centers[k][j])**2 for j in range(2))) for row in z]
  history.append({'iteration':iteration+1,'labels':labels[:],'centers':[c[:] for c in centers]})
  new=[[statistics.mean(z[n][j] for n,l in enumerate(labels) if l==k) for j in range(2)] for k in range(3)]
  if labels==last:centers=new;break
  last=labels[:];centers=new
 groups=[{'id':k+1,'count':labels.count(k),'visits_mean':statistics.mean(data[n][0] for n,l in enumerate(labels) if l==k),'spend_mean':statistics.mean(data[n][1] for n,l in enumerate(labels) if l==k)} for k in range(3)]
 return {'algorithm':'K-means con K=3; inicialización en filas 1,7,13; estandarización z-score','features':['visitas_mes','compra_media_unidades_monetarias'],'data':data,'labels':labels,'history':history,'groups':groups,'note':'Clientes sintéticos; K=3 lo decide el experimento, no el algoritmo. Los nombres comerciales son interpretaciones posteriores.'}

def reinforcement():
 rng=random.Random(3103);size=4;goal=(3,3);walls={(1,1),(2,1)};actions=[(-1,0),(0,1),(1,0),(0,-1)];q=[[[0.0]*4 for _ in range(size)] for _ in range(size)]
 def step(state,a):
  nr=state[0]+actions[a][0];nc=state[1]+actions[a][1]
  if not(0<=nr<size and 0<=nc<size) or (nr,nc) in walls:return state,-2,False
  next_state=(nr,nc);return next_state,10 if next_state==goal else -1,next_state==goal
 episodes=[]
 for episode in range(600):
  state=(0,0);total=0;eps=max(.05,.9*(.992**episode));path=[state];rewards=[]
  for _ in range(60):
   a=rng.randrange(4) if rng.random()<eps else max(range(4),key=lambda a:q[state[0]][state[1]][a])
   nxt,reward,done=step(state,a);old=q[state[0]][state[1]][a]
   target=reward if done else reward+.9*max(q[nxt[0]][nxt[1]])
   q[state[0]][state[1]][a]=old+.25*(target-old);total+=reward;path.append(nxt);rewards.append(reward);state=nxt
   if done:break
  episodes.append({'episode':episode+1,'steps':len(rewards),'return':total,'reached_goal':state==goal,'path':path,'rewards':rewards})
 state=(0,0);path=[state];rewards=[]
 for _ in range(30):
  a=max(range(4),key=lambda a:q[state[0]][state[1]][a]);state,reward,done=step(state,a);path.append(state);rewards.append(reward)
  if done:break
 assert state==goal
 return {'algorithm':'Q-learning tabular; semilla 3103; 600 episodios; alpha=.25; gamma=.9; exploración epsilon decreciente','size':size,'walls':sorted(walls),'goal':goal,'rewards':{'step':-1,'blocked':-2,'goal':10},'first_episode':episodes[0],'last_training_episode':episodes[-1],'greedy_evaluation':{'path':path,'rewards':rewards,'steps':len(rewards),'return':sum(rewards),'reached_goal':state==goal},'history':[{'episode':e['episode'],'return':e['return'],'steps':e['steps']} for e in episodes],'q':q,'note':'Entorno simulado determinista muy pequeño. Resultados de esta ejecución; no se extrapolan a robots reales.'}

if __name__=='__main__':
 results={'supervised':supervised(),'clustering':clustering(),'reinforcement':reinforcement()}
 (ROOT/'resultados.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
 print('Supervisado:',results['supervised']['correct'],'/',results['supervised']['total'])
 print('Grupos:',results['clustering']['groups'])
 print('Refuerzo:',results['reinforcement']['greedy_evaluation'])
