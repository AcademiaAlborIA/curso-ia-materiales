from pathlib import Path
from collections import deque
import json
from laboratorio import supervised,clustering,reinforcement
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'resultados.json').read_text(encoding='utf-8'))
fresh={'supervised':supervised(),'clustering':clustering(),'reinforcement':reinforcement()}
assert json.loads(json.dumps(fresh,ensure_ascii=False))==r,'Los resultados guardados no corresponden al programa.'
s=r['supervised'];assert s['correct']==5 and s['total']==6
assert not ({tuple(v[:2]) for v in s['train']}&{(v['x'],v['y']) for v in s['test']})
k=r['clustering'];assert len(k['labels'])==18 and sum(g['count'] for g in k['groups'])==18
assert all(g['count']==6 for g in k['groups'])
rl=r['reinforcement'];path=rl['greedy_evaluation']['path'];walls={tuple(x) for x in rl['walls']}
assert path[0]==[0,0] and path[-1]==rl['goal']
for a,b in zip(path,path[1:]):
 assert sum(abs(a[j]-b[j]) for j in range(2))==1
 assert tuple(b) not in walls and all(0<=x<4 for x in b)
assert len(path)-1==6 and rl['greedy_evaluation']['return']==5
queue=deque([((0,0),0)]);seen={(0,0)};shortest=None
while queue:
 (row,col),dist=queue.popleft()
 if [row,col]==rl['goal']:shortest=dist;break
 for dr,dc in [(-1,0),(0,1),(1,0),(0,-1)]:
  nxt=(row+dr,col+dc)
  if all(0<=v<4 for v in nxt) and nxt not in walls and nxt not in seen:seen.add(nxt);queue.append((nxt,dist+1))
assert shortest==6
print('OK: resultados reproducibles, seis casos nuevos, grupos completos y trayectoria legal hasta la meta.')
