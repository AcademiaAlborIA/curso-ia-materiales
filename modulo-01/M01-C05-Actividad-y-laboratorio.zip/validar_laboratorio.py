from pathlib import Path
import json,datetime
import numpy as np
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'resultados.json').read_text(encoding='utf-8'));fit=r['overfit'];x=np.array(fit['train_x']);y=np.array(fit['train_y']);vx=np.array(fit['validation_x']);vy=np.array(fit['validation_y'])
assert not set(x)&set(vx)
for degree in ['1','5']:
 m=fit['models'][degree];pred=np.polynomial.polynomial.polyval((x-2.5)/2.5,m['coefficients']);vp=np.polynomial.polynomial.polyval((vx-2.5)/2.5,m['coefficients'])
 assert np.isclose(np.mean((pred-y)**2),m['train_mse'])
 assert np.isclose(np.mean((vp-vy)**2),m['validation_mse'])
assert fit['models']['5']['train_mse']<1e-20
assert fit['models']['1']['validation_mse']<fit['models']['5']['validation_mse']
assert round(fit['models']['1']['validation_mse'],2)==.03 and round(fit['models']['5']['validation_mse'],2)==2.96
c=r['calculation'];assert sum(x['quantity']*x['unit_cents'] for x in c['items'])==1900
assert c['subtotal_cents']-c['discount_cents']+c['shipping_cents']==c['total_cents']==2060
assert c['wrong_example_cents']==1710
d=r['ambiguous_date'];assert d['day_month_year']=='2027-04-03' and d['month_day_year']=='2027-03-04'
assert r['source']['room']=='Aula 2' and [x['status'] for x in r['claims']]==['Respaldada','Contradicha','No consta']
print('OK: errores de ajuste y validación, formatos de fecha, evidencia de la ficha y cálculo completo.')
