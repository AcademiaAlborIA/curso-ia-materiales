"""Experimentos y comprobaciones para una lección sobre errores de IA."""
from pathlib import Path
import json,datetime
import numpy as np
ROOT=Path(__file__).resolve().parent
def run():
 x=np.arange(6,dtype=float);truth=lambda a:2*a+1
 y=truth(x)+np.array([0,1,-1,1,-1,1],dtype=float)
 val=np.array([.5,1.5,2.5,3.5,4.5]);yv=truth(val)
 models={}
 for degree in [1,5]:
  # Normalize x for better numerical conditioning of the polynomial fit.
  coeff=np.polynomial.polynomial.polyfit((x-2.5)/2.5,y,degree)
  predict=lambda a:np.polynomial.polynomial.polyval((np.asarray(a)-2.5)/2.5,coeff)
  xx=np.linspace(0,5,151)
  models[str(degree)]={'degree':degree,'coefficients':coeff.tolist(),'train_mse':float(np.mean((predict(x)-y)**2)),'validation_mse':float(np.mean((predict(val)-yv)**2)),'validation_predictions':predict(val).tolist(),'curve_x':xx.tolist(),'curve_y':predict(xx).tolist()}
 source={'title':'Taller Horizonte — ficha ficticia','date':'14 de mayo de 2027','start':'09:00','room':'Aula 2','price':'Entrada gratuita','note':'La ficha no indica si se incluyen materiales.'}
 claims=[{'claim':'El taller será el 14 de mayo de 2027.','status':'Respaldada','evidence':'Fecha: 14 de mayo de 2027.'},{'claim':'Se realizará en el Aula 3.','status':'Contradicha','evidence':'La ficha dice Aula 2.'},{'claim':'Los materiales están incluidos.','status':'No consta','evidence':'La ficha no informa sobre materiales.'}]
 items=[{'item':'Cuadernos','quantity':3,'unit_cents':450},{'item':'Lápices','quantity':2,'unit_cents':275}]
 subtotal=sum(r['quantity']*r['unit_cents'] for r in items);discount=subtotal//10;shipping=350;total=subtotal-discount+shipping
 date_text='03/04/2027';dates={'day_month_year':datetime.datetime.strptime(date_text,'%d/%m/%Y').date().isoformat(),'month_day_year':datetime.datetime.strptime(date_text,'%m/%d/%Y').date().isoformat()}
 result={'overfit':{'train_x':x.tolist(),'train_y':y.tolist(),'validation_x':val.tolist(),'validation_y':yv.tolist(),'generating_rule':'y=2x+1; entrenamiento con ruido fijo; validación sin ruido','models':models,'note':'Datos sintéticos, 6 puntos de ajuste y 5 de validación. La validación se usa para comparar modelos; no es una evaluación final independiente.'},'source':source,'claims':claims,'claim_note':'Respuesta de ejemplo inventada por el curso para practicar verificación. No es una salida capturada de un asistente real. La comprobación se realiza contra una ficha ficticia conocida.','calculation':{'items':items,'subtotal_cents':subtotal,'discount_percent':10,'discount_cents':discount,'shipping_cents':shipping,'total_cents':total,'wrong_example_cents':subtotal-discount},'ambiguous_date':{'input':date_text,**dates}}
 (ROOT/'resultados.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 (ROOT/'ficha-ficticia.txt').write_text('TALLER HORIZONTE — EJEMPLO FICTICIO\nFecha: 14 de mayo de 2027\nInicio: 09:00\nLugar: Aula 2\nPrecio: entrada gratuita\nLa ficha no indica si se incluyen materiales.\n',encoding='utf-8')
 print('Modelo lineal:',models['1']['train_mse'],models['1']['validation_mse'])
 print('Polinomio grado 5:',models['5']['train_mse'],models['5']['validation_mse'])
 print('Total verificado:',total,'centavos; interpretaciones de fecha:',dates)
 return result
if __name__=='__main__':run()
