from pathlib import Path
import json,subprocess,sys,os
from enrutador import fit,predict,tokens,evaluate,VALID,TEST
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'resultados.json').read_text(encoding='utf-8'));model=json.loads((ROOT/'modelo.json').read_text(encoding='utf-8'));data=json.loads((ROOT/'datos.json').read_text(encoding='utf-8'))
assert model==r['model']==fit()
assert len(data['train'])==18 and len(data['validation'])==len(data['test'])==6
sets=[{row['text'] for row in data[key]} for key in ['train','validation','test']]
assert not sets[0]&sets[1] and not sets[0]&sets[2] and not sets[1]&sets[2]
vocabulary=set(w for row in data['train'] for w in tokens(row['text']))
assert vocabulary==set(model['vocabulary']) and 'rastreo' not in vocabulary and 'factura' not in vocabulary
assert evaluate(model,VALID)==r['validation'] and evaluate(model,TEST)==r['test']
assert r['validation']['baseline_correct']==2 and r['validation']['model_correct']==6
assert r['test']['model_correct']==6 and r['test']['review_count']==0
assert predict(model,'Necesito factura fiscal')['route']=='Revision'
assert predict(model,'Quiero saber sobre envio y reembolso')['route']=='Revision'
assert predict(model,'Factura del paquete')['route']=='Envio'
process_env={**os.environ,'PYTHONIOENCODING':'utf-8'}
raw=subprocess.check_output([sys.executable,str(ROOT/'enrutador.py'),'--consultar','Quiero devolver mi articulo'],env=process_env)
assert json.loads(raw)==json.loads((ROOT/'demo-consulta.json').read_bytes())
interactive=subprocess.run([sys.executable,str(ROOT/'enrutador.py'),'--interactivo'],input='Quiero devolver mi articulo\nsalir\n',text=True,encoding='utf-8',env=process_env,capture_output=True,check=True)
assert 'Devolucion' in interactive.stdout
print('OK: separación, vocabulario, métricas, revisiones, fallo conocido y consulta real reproducible.')
