"""Enrutador didáctico de consultas sintéticas. Solo biblioteca estándar."""
from pathlib import Path
from collections import Counter
import math,re,json,unicodedata,argparse
ROOT=Path(__file__).resolve().parent
LABELS=['Envio','Devolucion','Producto']
STOP=set('el la los las un una unos unas de del al a en con por para y o que mi mis su sus se me es esta este esto como donde cuando quiero necesito puedo saber tengo hay sobre cuanto cual favor por favor'.split())
TRAIN={
'Envio':['Cuando llega el paquete de mi pedido','Quiero seguir el envio del paquete','La entrega de mi pedido esta retrasada','Cual es el costo del envio','No encuentro el seguimiento de la entrega','El paquete no llega a mi direccion'],
'Devolucion':['Quiero devolver un pedido recibido','Como solicito el reembolso de una devolucion','Necesito cambiar un articulo por otro','El producto llego roto y pido reembolso','Cual es el plazo para devolver un articulo','Como tramitar una devolucion por defecto'],
'Producto':['Que talla tiene esta camisa','Hay otro color disponible para este producto','Quiero conocer las medidas del articulo','Cual es el precio de esta mochila','Este modelo esta disponible en azul','La descripcion indica el material del producto']}
VALID=[('Mi paquete tiene retraso','Envio'),('Costo para envio a mi direccion','Envio'),('Como tramitar un reembolso','Devolucion'),('Quiero devolver este articulo','Devolucion'),('Hay talla disponible en azul','Producto'),('Precio y material de la mochila','Producto')]
TEST=[('El seguimiento del paquete no cambia','Envio'),('Mi compra no aparece y busco rastreo','Envio'),('El articulo tiene un defecto y quiero reembolso','Devolucion'),('Cual es el plazo de devolucion','Devolucion'),('Las medidas de esta camisa','Producto'),('Este modelo viene en otro color','Producto')]
CHALLENGES=['Necesito factura fiscal','Quiero saber sobre envio y reembolso','Factura del paquete']
def tokens(text):
 text=''.join(c for c in unicodedata.normalize('NFD',text.lower()) if unicodedata.category(c)!='Mn')
 return [w for w in re.findall(r'[a-z]+',text) if w not in STOP]
def fit():
 rows=[{'text':text,'label':label} for label in LABELS for text in TRAIN[label]]
 counts={label:Counter() for label in LABELS};documents=Counter(r['label'] for r in rows)
 for row in rows:counts[row['label']].update(tokens(row['text']))
 vocab=sorted(set().union(*(set(c) for c in counts.values())))
 return {'version':'didactico-v1','labels':LABELS,'vocabulary':vocab,'counts':{k:dict(v) for k,v in counts.items()},'totals':{k:sum(v.values()) for k,v in counts.items()},'documents':dict(documents),'alpha':1,'training_rows':rows}
def load_model():
 path=ROOT/'modelo.json'
 return json.loads(path.read_text(encoding='utf-8')) if path.exists() else fit()
def predict(model,text):
 words=tokens(text);vocab=set(model['vocabulary']);known=[w for w in words if w in vocab];scores={}
 for label in model['labels']:
  score=math.log(model['documents'][label]/sum(model['documents'].values()))
  for w in known:score+=math.log((model['counts'][label].get(w,0)+1)/(model['totals'][label]+len(vocab)))
  scores[label]=score
 label=max(model['labels'],key=lambda label:scores[label])
 anchors={'Envio':{'envio','entrega','paquete'},'Devolucion':{'devolver','devolucion','reembolso'},'Producto':{'talla','color','medidas','material'}}
 detected=[label for label,keys in anchors.items() if set(words)&keys]
 reason='Sin palabras conocidas' if not known else 'Posibles intenciones mezcladas' if len(detected)>1 else None
 return {'text':text,'tokens':words,'known_tokens':known,'model_label':label,'route':'Revision' if reason else label,'review_reason':reason,'log_scores':scores}
def evaluate(model,rows):
 cases=[{**predict(model,text),'expected':label} for text,label in rows]
 return {'total':len(cases),'model_correct':sum(c['model_label']==c['expected'] for c in cases),'review_count':sum(c['route']=='Revision' for c in cases),'automatic_count':sum(c['route']!='Revision' for c in cases),'automatic_correct':sum(c['route']!='Revision' and c['route']==c['expected'] for c in cases),'baseline_correct':sum(c['expected']=='Envio' for c in cases),'cases':cases}
def run():
 model=fit();result={'model':model,'validation':evaluate(model,VALID),'test':evaluate(model,TEST),'challenges':[predict(model,text) for text in CHALLENGES],'notes':['Consultas sintéticas; no son mensajes de clientes.','El vocabulario y los conteos se obtienen solo de entrenamiento.','Baseline fijo: enviar todo a Envio.','Reglas de revisión escritas a mano: cero palabras conocidas o varios grupos de palabras ancla. No garantizan detectar todos los errores.','No se muestran los scores como confianza calibrada.','Los conjuntos se fijaron para la lección. Las métricas de seis casos no estiman rendimiento de producción.']}
 (ROOT/'modelo.json').write_text(json.dumps(model,ensure_ascii=False,indent=2),encoding='utf-8')
 (ROOT/'resultados.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 (ROOT/'datos.json').write_text(json.dumps({'train':model['training_rows'],'validation':[{'text':t,'label':l} for t,l in VALID],'test':[{'text':t,'label':l} for t,l in TEST]},ensure_ascii=False,indent=2),encoding='utf-8')
 print('Validación:',result['validation']['model_correct'],'/',len(VALID),'revisión:',result['validation']['review_count'])
 print('Prueba final:',result['test']['model_correct'],'/',len(TEST),'revisión:',result['test']['review_count'])
 print('Casos de desafío:',[(r['text'],r['model_label'],r['route']) for r in result['challenges']])
 return result
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--consultar');parser.add_argument('--interactivo',action='store_true');args=parser.parse_args()
 if args.interactivo:
  model=load_model();print('Enrutador didáctico local. Escribe salir para terminar. No uses datos personales.')
  while True:
   text=input('Consulta: ').strip()
   if text.lower()=='salir':break
   if not text:continue
   result=predict(model,text);print('Área sugerida:',result['route'],'| Modelo:',result['model_label'])
   if result['review_reason']:print('Motivo:',result['review_reason'])
 elif args.consultar:print(json.dumps(predict(load_model(),args.consultar),ensure_ascii=False,indent=2))
 else:run()
