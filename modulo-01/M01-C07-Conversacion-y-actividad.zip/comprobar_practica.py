"""Comprobaciones mecánicas de la conversación guardada, no un verificador universal de hechos."""
from pathlib import Path
import json,unicodedata
P=Path(__file__).resolve().parent;r=json.loads((P/'conversacion-real.json').read_text(encoding='utf-8'))
counts=[len(text.split()) for text in r['responses']]
assert counts==r['word_counts']==[63,42]
text=r['responses'][1];normalized=unicodedata.normalize('NFD',text.lower()).encode('ascii','ignore').decode()
assert len(text.split())<=45
assert all(word in text for word in ['A104','Lumen','retraso','no hay una nueva fecha de entrega confirmada'])
assert normalized.count('actualizacion')<=1
assert all(word not in normalized for word in ['manana','descuento','politica','puedes responder'])
assert '45 palabras' in r['correction']
print('OK: 63 y 42 palabras; máximo 45; datos clave presentes y sin fecha prometida en el texto guardado.')
print('La fidelidad completa y la utilidad deben revisarse contra el caso. Tus respuestas pueden variar.')
