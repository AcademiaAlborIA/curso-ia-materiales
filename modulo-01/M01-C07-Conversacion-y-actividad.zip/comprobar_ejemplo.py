"""Comprobación mecánica del ejemplo didáctico; no valida respuestas de IA."""
TEXTO='Hola, el transportista reporta un retraso en tu pedido A104 de Lumen. Aún no tenemos una nueva fecha de entrega confirmada. Te informaremos cuando haya novedades. Gracias por tu paciencia.'
if __name__=='__main__':
 cantidad=len(TEXTO.split())
 assert cantidad==30 and cantidad<=45
 assert all(x in TEXTO for x in ['A104','Lumen','retraso','no tenemos una nueva fecha'])
 print(f'Ejemplo: {cantidad} palabras. Máximo de 45 respetado.')
 print('Identificador, tienda, retraso y falta de fecha presentes.')
 print('La revisión de hechos y utilidad requiere comparar con la fuente.')
