"""Validador automático de salidas generativas frente a las 4 piezas del prompt (M04-C02)."""
import json
from pathlib import Path

datos = json.loads((Path(__file__).parent / "plantillas_faro.json").read_text(encoding="utf-8"))
regla = datos["caso_club_lectura"]

print("=== VALIDACIÓN AUTOMÁTICA DE BORRADORES (LIBRERÍA FARO) ===")
for b in datos["borradores_club_para_validar"]:
    txt = b["texto"]
    n_pal = len(txt.split())
    faltan = [x for x in regla["obligatorias"] if x.lower() not in txt.lower()]
    inventos = [x for x in regla["prohibidas"] if x.lower() in txt.lower()]
    relleno = txt.strip().lower().startswith(("¡claro!", "claro,", "con mucho gusto"))
    ok = (n_pal <= regla["max_palabras"]) and not faltan and not inventos and not relleno
    estado = "APROBADO" if ok else "RECHAZADO"
    print(f"  {b['id']} [{estado}] palabras={n_pal}/{regla['max_palabras']} | faltan={faltan} | inventos={inventos} | relleno={relleno}")
