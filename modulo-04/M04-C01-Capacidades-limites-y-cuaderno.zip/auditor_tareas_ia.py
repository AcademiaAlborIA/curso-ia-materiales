"""Auditor práctico de tareas y borradores para Librería Faro (M04-C01)."""
import json
from pathlib import Path

datos = json.loads((Path(__file__).parent / "casos_libreria_faro.json").read_text(encoding="utf-8"))
reglas = datos["reglas_faro"]

print("=== 1. SEMÁFORO DE TAREAS (VERDE / ÁMBAR / ROJO) ===")
for t in datos["tareas_semaforo"]:
    print(f"  [{t['color_correcto']:5s}] #{t['id']}: {t['tarea']}")

print("\n=== 2. AUDITORÍA DE BORRADORES CONTRA REGLAS OFICIALES ===")
for b in datos["borradores_auditoria"]:
    marca = "OK" if b["es_fiel"] else "ALUCINACION DETECTADA"
    print(f"  {b['id']} [{marca}]: {b['hallazgo']}")

ventas = reglas["pedidos_abril_usd"]
print("\n=== 3. CÁLCULO EXACTO EN PYTHON ANTES DE REDACTAR ===")
print(f"  Pedidos: {len(ventas)} | Total: ${sum(ventas):.2f} USD | Promedio: ${sum(ventas)/len(ventas):.2f} USD")
