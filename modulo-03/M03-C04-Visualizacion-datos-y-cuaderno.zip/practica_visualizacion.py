import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv("casas_200.csv")
print("Forma:", df.shape)
print("\nCorrelación con precio:")
print(df.corr(numeric_only=True)["precio"].round(2))

con = df[df["jardin"]]
sin = df[~df["jardin"]]
tramo_con = con[(con["metros"] >= 80) & (con["metros"] <= 110)]["precio"].mean()
tramo_sin = sin[(sin["metros"] >= 80) & (sin["metros"] <= 110)]["precio"].mean()
print(f"\nReto (80-110 m²) -> Con jardín: {tramo_con:,.0f} | Sin jardín: {tramo_sin:,.0f} (+{tramo_con - tramo_sin:,.0f})")

plt.figure(figsize=(7, 4.5))
plt.scatter(sin["metros"], sin["precio"], alpha=0.7)
plt.scatter(con["metros"], con["precio"], alpha=0.8)
plt.legend(["sin jardín", "con jardín"])
plt.xlabel("metros")
plt.ylabel("precio")
plt.title("Reto M03-C04: ¿Cuánto suma el jardín?")
plt.tight_layout()
plt.savefig("reto_jardin_dispersion.png", dpi=140)
print("Gráfico guardado en reto_jardin_dispersion.png")
