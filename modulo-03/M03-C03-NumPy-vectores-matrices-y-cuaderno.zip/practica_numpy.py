import numpy as np
import pandas as pd

df = pd.read_csv("casas_limpias.csv")
X = df[["metros", "habitaciones", "jardin"]].astype(float).to_numpy()
precios = df["precio"].to_numpy()

pesos_1 = np.array([1000.0, 10000.0, 15000.0])
pesos_2 = np.array([1200.0, 5000.0, 20000.0])

err_1 = np.abs(precios - (X @ pesos_1)).mean()
err_2 = np.abs(precios - (X @ pesos_2)).mean()

print("Error medio [1000, 10000, 15000]:", round(float(err_1), 2))
print("Error medio [1200,  5000, 20000]:", round(float(err_2), 2))
