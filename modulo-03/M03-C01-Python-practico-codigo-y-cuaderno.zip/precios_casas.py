"""Funciones del predictor manual de precios de casas — Academia Albor IA (M03-C01)."""


def predecir_precio(metros, precio_por_metro=1500.0):
    """Calcula el precio estimado de una casa validando que los metros sean positivos."""
    if isinstance(metros, bool):
        raise TypeError("Los metros deben ser un número (int o float), no un booleano")
    if metros <= 0:
        raise ValueError("Los metros deben ser mayores que 0")
    return metros * precio_por_metro


def predecir_precio_v2(metros):
    """Versión de la Pausa 3 que solo usa print() y no devuelve nada (retorna None)."""
    print(metros * 1500.0)


def categoria_precio(precio):
    """Clasifica el precio de una casa en 'cara', 'media' o 'económica'."""
    if isinstance(precio, bool):
        raise TypeError("El precio debe ser numérico")
    if precio > 150000:
        return "cara"
    elif precio > 80000:
        return "media"
    else:
        return "económica"


def procesar_entrada_texto(entrada, precio_por_metro=1500.0):
    """Convierte texto del usuario a float y calcula el precio con manejo limpio de ValueError."""
    try:
        metros = float(entrada)
        precio = predecir_precio(metros, precio_por_metro=precio_por_metro)
        return {"ok": True, "metros": metros, "precio": precio, "mensaje": f"{precio}"}
    except ValueError as err:
        msg = (
            str(err)
            if "mayores que 0" in str(err)
            else "Escribe los metros con números, por ejemplo: 80"
        )
        return {"ok": False, "entrada": entrada, "error": "ValueError", "mensaje": msg}


def clasificar_lista_casas(casas, precio_por_metro=1500.0):
    """Recorre una lista de metros cuadrados y devuelve precio y categoría de cada casa."""
    resultados = []
    for m in casas:
        p = predecir_precio(m, precio_por_metro=precio_por_metro)
        resultados.append(
            {
                "metros": m,
                "precio": p,
                "categoria": categoria_precio(p),
            }
        )
    return resultados
