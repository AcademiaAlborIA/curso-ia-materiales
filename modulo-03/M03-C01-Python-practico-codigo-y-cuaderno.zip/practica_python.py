"""Demostración paso a paso de M03-C01: Variables, Condiciones, Funciones y Errores."""
import io
import json
from contextlib import redirect_stdout
from pathlib import Path

from precios_casas import (
    categoria_precio,
    clasificar_lista_casas,
    predecir_precio,
    predecir_precio_v2,
    procesar_entrada_texto,
)

ROOT = Path(__file__).resolve().parent


def main():
    print("=== MÓDULO 3 · CAPÍTULO 1 — PYTHON PRÁCTICO ===")

    # 1. Variables y tipos de datos
    metros = 80
    precio_por_metro = 1500.0
    barrio = "Centro"
    tiene_jardin = True
    precio = metros * precio_por_metro
    casas = [50, 80, 120]

    print("\n1 · VARIABLES Y TIPOS")
    print(f"metros = {metros} -> {type(metros).__name__}")
    print(f"precio_por_metro = {precio_por_metro} -> {type(precio_por_metro).__name__}")
    print(f"barrio = {barrio!r} -> {type(barrio).__name__}")
    print(f"tiene_jardin = {tiene_jardin} -> {type(tiene_jardin).__name__}")
    print(f"precio = {precio} -> {type(precio).__name__}")
    print(f"casas = {casas} | primera posición casas[0] = {casas[0]}")

    # Pausa 1
    pausa_1_texto = "80"
    pausa_1_mult = 80 * 1500.0
    print(f"Pausa 1 -> type('80') = {type(pausa_1_texto).__name__}, type(80 * 1500.0) = {type(pausa_1_mult).__name__}")

    # 2. Condiciones
    print("\n2 · CONDICIONES (if / elif / else)")
    cat_casa_actual = categoria_precio(precio)
    print(f"Casa de {precio}: categoría = {cat_casa_actual}")
    if tiene_jardin and metros > 100:
        msg_jardin = "Casa grande con jardín"
    else:
        msg_jardin = "No cumple las dos condiciones"
    print(f"tiene_jardin and metros > 100 -> {msg_jardin}")
    print(f"Pausa 2 -> Si precio == 80000, sale: {categoria_precio(80000)!r} (porque 80000 > 80000 es False)")

    # 3. Funciones
    print("\n3 · FUNCIONES (def / return vs print)")
    print("predecir_precio(80) =", predecir_precio(80))
    print("predecir_precio(120) =", predecir_precio(120))
    print("predecir_precio(80, 2000) =", predecir_precio(80, 2000))

    buf = io.StringIO()
    with redirect_stdout(buf):
        resultado_v2 = predecir_precio_v2(100)
    impreso_v2 = buf.getvalue().strip()
    print(f"Pausa 3 -> En pantalla mostró {impreso_v2}, pero resultado guardó: {resultado_v2!r}")

    # 4. Errores, try/except y raise
    print("\n4 · ERRORES, TRY / EXCEPT Y RAISE")
    try:
        predecir_precio("80")
    except TypeError as err:
        error_texto = f"TypeError: {err}"
        print(f"Pasar '80' con comillas lanza -> {error_texto}")

    prueba_letras = procesar_entrada_texto("ochenta")
    print(f"Entrada 'ochenta' con try/except -> {prueba_letras['mensaje']}")

    try:
        predecir_precio(0)
    except ValueError as err:
        error_cero = f"ValueError: {err}"
        print(f"Casa de 0 metros lanza -> {error_cero}")

    # Reto final
    print("\nRETO · CLASIFICAR LAS 3 CASAS DE LA LISTA [50, 80, 120]")
    reto_resultados = clasificar_lista_casas(casas)
    for fila in reto_resultados:
        print(f"  {fila['metros']} m² -> {fila['precio']} -> {fila['categoria']}")

    resumen = {
        "casa_ejemplo": {
            "metros": metros,
            "precio_por_metro": precio_por_metro,
            "barrio": barrio,
            "tiene_jardin": tiene_jardin,
            "precio": precio,
            "categoria": cat_casa_actual,
        },
        "pausas": {
            "pausa_1": {"tipo_comillas_80": type(pausa_1_texto).__name__, "tipo_80_por_1500_0": type(pausa_1_mult).__name__},
            "pausa_2": {"precio_80000": categoria_precio(80000)},
            "pausa_3": {"impreso_en_pantalla": impreso_v2, "guardado_en_resultado": resultado_v2},
        },
        "errores_controlados": {
            "texto_80": error_texto,
            "entrada_ochenta": prueba_letras["mensaje"],
            "metros_cero": error_cero,
        },
        "reto_tres_casas": reto_resultados,
    }
    (ROOT / "salida-demostraciones.json").write_text(
        json.dumps(resumen, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
