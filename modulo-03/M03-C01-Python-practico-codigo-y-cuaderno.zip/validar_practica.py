"""Pruebas automáticas con assert para verificar la práctica y el reto de M03-C01."""
import io
import json
from contextlib import redirect_stdout
from pathlib import Path

from precios_casas import (
    categoria_precio,
    clasificar_lista_casas,
    predecir_precio,
    predecir_precio_v2,
    procesar_entrada_texto,
)

ROOT = Path(__file__).resolve().parent


def main():
    # 1. Variables y Pausa 1
    assert isinstance("80", str)
    assert isinstance(80 * 1500.0, float)
    casas = [50, 80, 120]
    assert casas[0] == 50 and casas[1] == 80 and casas[2] == 120

    # 2. Condiciones y Pausa 2 (bordes exactos)
    assert categoria_precio(75000.0) == "económica"
    assert categoria_precio(80000) == "económica"
    assert categoria_precio(80000.01) == "media"
    assert categoria_precio(120000.0) == "media"
    assert categoria_precio(150000) == "media"
    assert categoria_precio(150000.01) == "cara"
    assert categoria_precio(180000.0) == "cara"

    # 3. Funciones y Pausa 3 (return vs print)
    assert predecir_precio(80) == 120000.0
    assert predecir_precio(120) == 180000.0
    assert predecir_precio(80, 2000) == 160000

    buf = io.StringIO()
    with redirect_stdout(buf):
        guardado = predecir_precio_v2(100)
    assert buf.getvalue().strip() == "150000.0"
    assert guardado is None

    # 4. Errores (TypeError, try/except ValueError y raise ValueError)
    try:
        predecir_precio("80")
        raise AssertionError("Debía lanzar TypeError al pasar texto '80'")
    except TypeError:
        pass

    for invalido in (0, -25):
        try:
            predecir_precio(invalido)
            raise AssertionError(f"Debía lanzar ValueError para metros={invalido}")
        except ValueError as err:
            assert "Los metros deben ser mayores que 0" in str(err)

    r_mal = procesar_entrada_texto("ochenta")
    assert r_mal["ok"] is False and r_mal["mensaje"] == "Escribe los metros con números, por ejemplo: 80"
    r_bien = procesar_entrada_texto("80")
    assert r_bien["ok"] is True and r_bien["precio"] == 120000.0

    # 5. Reto de las 3 casas [50, 80, 120]
    lote = clasificar_lista_casas(casas)
    assert [x["precio"] for x in lote] == [75000.0, 120000.0, 180000.0]
    assert [x["categoria"] for x in lote] == ["económica", "media", "cara"]

    reporte = {
        "validacion": "OK",
        "pruebas_superadas": 15,
        "categorias_reto": [x["categoria"] for x in lote],
    }
    (ROOT / "verificacion-practica.json").write_text(
        json.dumps(reporte, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print("VALIDACIÓN AUTOMÁTICA M03-C01 SUPERADA: 15/15 comprobaciones exactas (económica · media · cara).")


if __name__ == "__main__":
    main()
