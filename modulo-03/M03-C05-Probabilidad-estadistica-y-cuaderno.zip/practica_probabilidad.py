import numpy as np
import pandas as pd

df = pd.read_csv("casas_200.csv")
print("Media:", round(df["precio"].mean(), 1), "| Mediana:", round(df["precio"].median(), 1))
print("Desviación estándar:", round(df["precio"].std(), 1))

print("\n1) P(jardín) por barrio:")
print((df.groupby("barrio")["jardin"].mean() * 100).round(1))

p_cara_jardin = (df[df["jardin"]]["precio"] > 150000).mean()
print(f"\n2) P(precio > 150 mil | jardín): {p_cara_jardin:.1%}")

m_pend, b_int = np.polyfit(df["metros"], df["precio"], 1)
margen = 2 * (df["precio"] - (m_pend * df["metros"] + b_int)).std()
for metros in [70, 130]:
    pred = m_pend * metros + b_int
    print(f"3) {metros} m² -> {pred:,.0f} (entre {pred - margen:,.0f} y {pred + margen:,.0f})")
