import numpy as np
import pandas as pd

df = pd.read_csv("casas_200.csv")
x = df["metros"].to_numpy()
y = df["precio"].to_numpy() / 1000.0

def error(w):
    return ((y - w * x) ** 2).mean()

def gradiente(w):
    return -2 * (x * (y - w * x)).mean()

for p in [0.00001, 0.00002, 0.00005]:
    w, k = 0.5, 0
    while round(w, 2) != 1.40 and k < 500:
        w -= p * gradiente(w)
        k += 1
    print(f"paso={p:.5f} -> w={w:.3f} en {k} pasos (error={error(w):.1f})")

w3 = 3.0
for _ in range(15):
    w3 -= 0.00002 * gradiente(w3)
print(f"Desde w=3.0 -> w={w3:.3f}")
