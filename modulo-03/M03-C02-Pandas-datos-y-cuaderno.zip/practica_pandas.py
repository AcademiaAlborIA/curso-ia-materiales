import pandas as pd

df = pd.read_csv("casas.csv")
df["metros"] = df["metros"].fillna(df["metros"].median())
df["precio_m2"] = (df["precio"] / df["metros"]).round(2)
df.to_csv("casas_limpias.csv", index=False)

num_3hab = df[df["habitaciones"] >= 3].shape[0]
mas_barata = df.sort_values("precio_m2", ascending=True).iloc[0]
prom_jardin = df.groupby("jardin")["precio"].mean()
dif_jardin = round(float(prom_jardin[True] - prom_jardin[False]), 2)

print("1) Casas con 3+ habitaciones:", num_3hab)
print(f"2) Más barata por m²: fila {mas_barata.name} ({mas_barata['barrio']}, {mas_barata['metros']} m², {mas_barata['precio']} -> {mas_barata['precio_m2']}/m²)")
print("3) Promedio con jardín vs sin jardín:", prom_jardin.round(2).to_dict(), "-> Diferencia:", dif_jardin)
