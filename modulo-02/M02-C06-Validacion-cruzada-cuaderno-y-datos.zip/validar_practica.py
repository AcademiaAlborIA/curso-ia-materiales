"""Pruebas del reparto, predicciones manuales/API y ausencia de prueba en la selección."""
import copy
from pathlib import Path
import numpy as np
from sklearn.model_selection import cross_val_predict,StratifiedKFold
from sklearn.tree import DecisionTreeClassifier
import practica as p
rows=p.cargar();r=p.seleccionar(rows);dev=r['desarrollo'];ids={x['pedido'] for x in dev};seen=[]
assert len(rows)==32 and len(dev)==24 and sum(x['grupo']=='prueba' for x in rows)==8
assert len({x['pedido'] for x in rows})==32
for f in r['particiones']:
 a=set(f['ajuste']);v=set(f['validacion']);assert len(a)==16 and len(v)==8 and not a&v and a|v==ids;seen+=f['validacion']
assert len(seen)==len(set(seen))==24
assert [f['clases_validacion'] for f in r['particiones']]==[[5,3],[4,4],[4,4]]
assert [f['coste'] for f in r['resultados']['A']['vueltas']]==[6,2,11]
assert [f['coste'] for f in r['resultados']['Referencia']['vueltas']]==[15,20,20]
assert r['predicciones_oof']['A']==r['predicciones_oof']['B']
assert r['seleccion_congelada']['elegido']=='A'
assert r['resultados']['A']['fuera_de_ajuste']['aciertos']==17
assert r['resultados']['A']['fuera_de_ajuste']['coste']==19
X,y=p.arrays(dev);api=cross_val_predict(DecisionTreeClassifier(max_depth=1,random_state=7),X,y,cv=StratifiedKFold(n_splits=3,shuffle=True,random_state=7))
assert api.tolist()==[a['prediccion'] for a in r['predicciones_oof']['A']]
final=p.prueba_final(rows,r['seleccion_congelada']);assert (final['n_ajuste'],final['aciertos'],final['fn'],final['fp'],final['coste'])==(24,3,2,3,13)
altered=copy.deepcopy(rows)
for a in altered:
 if a['grupo']=='prueba':a['retraso']=1-a['retraso'];a['minutos_reales']=40 if a['retraso'] else 30
changed=p.seleccionar(altered);assert changed==r
assert p.prueba_final(altered,changed['seleccion_congelada'])['matriz']!=final['matriz']
alt=p.seleccionar(rows,19);assert alt['particiones']!=r['particiones'];assert [f['coste'] for f in alt['resultados']['A']['vueltas']]==[6,1,6]
assert 'prueba_final' not in alt
folder=Path(__file__).resolve().parent/'verificacion-csv';folder.mkdir(exist_ok=True);p.csv_write(folder/'datos.csv',rows);loaded=p.cargar(folder/'datos.csv');assert p.seleccionar(loaded)['resultados']==r['resultados']
loaded[0]['distancia_km']+=.25;p.csv_write(folder/'alterados.csv',loaded);assert p.cargar(folder/'alterados.csv')[0]['distancia_km']==rows[0]['distancia_km']+.25
print('VERIFICADO: cobertura 24/24, sin solapamiento dentro de vuelta, manual=API, costes, reajuste24, CSV leído y selección sin prueba.')
