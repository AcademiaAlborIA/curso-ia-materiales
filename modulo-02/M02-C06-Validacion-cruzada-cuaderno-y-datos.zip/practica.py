"""Validación cruzada estratificada: datos ficticios, modelos nuevos por vuelta y prueba aparte."""
import argparse,csv,hashlib,json
from pathlib import Path
import numpy as np
import sklearn
from sklearn.base import clone
from sklearn.dummy import DummyClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import confusion_matrix,accuracy_score
FEATURES=['distancia_km','pedidos_pendientes'];NOMBRES={0:'En plazo',1:'Retraso'}
def generar():
 rng=np.random.default_rng(2026);rows=[]
 for k in range(32):
  d=round(float(rng.uniform(1,8)),1);p=int(rng.integers(1,9));m=max(12,int(round(10+3*d+2*p+rng.normal(0,5))))
  rows.append(dict(pedido=('D' if k<24 else 'F')+f'{k+1 if k<24 else k-23:02}',grupo='desarrollo' if k<24 else 'prueba',distancia_km=d,pedidos_pendientes=p,minutos_reales=m,retraso=int(m>35)))
 return rows
def cargar(path=None):
 if path is None:return generar()
 with Path(path).open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
 for r in rows:
  r['distancia_km']=float(r['distancia_km']);r['pedidos_pendientes']=int(r['pedidos_pendientes']);r['minutos_reales']=int(r['minutos_reales']);r['retraso']=int(r['retraso'])
  if r['retraso']!=int(r['minutos_reales']>35) or r['grupo'] not in ['desarrollo','prueba']:raise ValueError('Etiqueta o grupo inválido')
 if len({r['pedido'] for r in rows})!=len(rows):raise ValueError('Pedido repetido')
 return rows
def arrays(rows):return np.array([[r[k] for k in FEATURES] for r in rows]),np.array([r['retraso'] for r in rows])
def medir(y,pred):
 tn,fp,fn,tp=map(int,confusion_matrix(y,pred,labels=[0,1]).ravel());return dict(n=len(y),tn=tn,fp=fp,fn=fn,tp=tp,matriz=[[tn,fp],[fn,tp]],aciertos=int((np.asarray(y)==pred).sum()),exactitud=float(accuracy_score(y,pred)),coste=5*fn+fp)
def candidatos():return {'Referencia':DummyClassifier(strategy='most_frequent'),'A':DecisionTreeClassifier(max_depth=1,random_state=7),'B':DecisionTreeClassifier(max_depth=2,random_state=7)}
def seleccionar(rows=None,semilla=7):
 rows=cargar() if rows is None else rows;dev=[r for r in rows if r['grupo']=='desarrollo'];X,y=arrays(dev)
 if min(np.bincount(y,minlength=2))<3:raise ValueError('Cada clase necesita al menos tres casos para tres particiones')
 cv=StratifiedKFold(n_splits=3,shuffle=True,random_state=semilla);splits=list(cv.split(X,y));folds=[];scores={};oof={}
 for f,(tr,va) in enumerate(splits):folds.append(dict(vuelta=f+1,ajuste=[dev[k]['pedido'] for k in tr],validacion=[dev[k]['pedido'] for k in va],clases_validacion=[int((y[va]==c).sum()) for c in [0,1]]))
 for nombre,base in candidatos().items():
  allpred=np.full(len(y),-1);seen=np.zeros(len(y),int);resultados=[]
  for f,(tr,va) in enumerate(splits):
   modelo=clone(base);modelo.fit(X[tr],y[tr]);pred=modelo.predict(X[va]);allpred[va]=pred;seen[va]+=1;m=medir(y[va],pred);m.update(vuelta=f+1,n_ajuste=len(tr),n_validacion=len(va),corte_raiz=float(modelo.tree_.threshold[0]) if hasattr(modelo,'tree_') else None);resultados.append(m)
  assert (seen==1).all()
  combined=medir(y,allpred);scores[nombre]=dict(vueltas=resultados,fuera_de_ajuste=combined,coste_medio=float(np.mean([m['coste'] for m in resultados])),coste_por_pedido=combined['coste']/len(y),exactitud_media=float(np.mean([m['exactitud'] for m in resultados])),desviacion_exactitud=float(np.std([m['exactitud'] for m in resultados])))
  oof[nombre]=[dict(**r,prediccion=int(p),vuelta=next(f+1 for f,(_,va) in enumerate(splits) if k in va)) for k,(r,p) in enumerate(zip(dev,allpred))]
 order=['Referencia','A','B'];winner=min(order,key=lambda n:(scores[n]['coste_medio'],order.index(n)))
 frozen=dict(elegido=winner,n_splits=3,shuffle=True,semilla_particion=semilla,criterio='menor coste medio por vuelta; empate Referencia, A, B',coste_fn=5,coste_fp=1,huella_desarrollo=hashlib.sha256(json.dumps(dev,sort_keys=True).encode()).hexdigest(),profundidad={'Referencia':None,'A':1,'B':2}[winner])
 return dict(origen='32 pedidos nuevos ficticios generados con semilla 2026. No se reutilizan las pruebas de capítulos anteriores.',features=FEATURES,desarrollo=dev,particiones=folds,resultados=scores,predicciones_oof=oof,seleccion_congelada=frozen,version_sklearn=sklearn.__version__)
def prueba_final(rows,seleccion):
 dev=[r for r in rows if r['grupo']=='desarrollo'];test=[r for r in rows if r['grupo']=='prueba'];X,y=arrays(dev);Xt,yt=arrays(test);model=clone(candidatos()[seleccion['elegido']]);model.fit(X,y);pred=model.predict(Xt);r=medir(yt,pred);r.update(n_ajuste=len(dev),casos=[dict(**a,prediccion=int(p)) for a,p in zip(test,pred)]);return r
def csv_write(path,rows):
 with Path(path).open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def exportar(folder,source=None,semilla=7,abrir=False):
 folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);rows=cargar(source);r=seleccionar(rows,semilla);save=lambda name,obj:(folder/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
 if source is None:csv_write(folder/'pedidos-validacion-cruzada.csv',rows)
 save('seleccion-congelada.json',r['seleccion_congelada'])
 print(f"Desarrollo: {len(r['desarrollo'])} | Prueba aparte: {sum(a['grupo']=='prueba' for a in rows)} | 3 particiones | semilla {semilla}")
 print('Positivo = Retraso >35 min; coste FN=5, FP=1. No son precios reales.')
 for name,m in r['resultados'].items():
  for f in m['vueltas']:print(f"{name} vuelta {f['vuelta']}: ajuste {f['n_ajuste']} | validación {f['n_validacion']} | aciertos {f['aciertos']}/{f['n_validacion']} | FN {f['fn']} FP {f['fp']} | coste {f['coste']}")
  print(f"{name}: coste medio {m['coste_medio']:.2f}; aciertos OOF {m['fuera_de_ajuste']['aciertos']}/{m['fuera_de_ajuste']['n']}")
  csv_write(folder/f'oof-{name}.csv',r['predicciones_oof'][name])
 print('Elección congelada:',r['seleccion_congelada']['elegido'])
 if abrir:
  r['prueba_final']=prueba_final(rows,r['seleccion_congelada']);m=r['prueba_final'];print(f"Reajuste con {m['n_ajuste']} desarrollo. PRUEBA: {m['aciertos']}/{m['n']} | FN {m['fn']} FP {m['fp']} | coste {m['coste']}");save('prueba-final.json',m)
 else:print('Prueba final NO evaluada. Abrir explícitamente con --prueba-final.')
 save('resultados.json',r);return r
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--csv',type=Path);p.add_argument('--semilla',type=int,default=7);p.add_argument('--prueba-final',action='store_true');p.add_argument('--salida',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args();exportar(a.salida,a.csv,a.semilla,a.prueba_final)
