import csv,json
from pathlib import Path
from experimento import ejecutar,ROWS,HEADERS
P=Path(__file__).resolve().parent
r=ejecutar()
assert r==json.loads((P/'resultados.json').read_text(encoding='utf-8'))
assert len(ROWS)==10 and len({x[0] for x in ROWS})==10
assert r['historicos']==6 and r['comprobacion']==4
assert r['referencia_minutos']==30 and r['mae_minutos']==10
assert [x['error_absoluto'] for x in r['casos']]==[10,0,10,20]
assert r['usa_caracteristicas'] is False
with (P/'pedidos.csv').open(encoding='utf-8',newline='') as f:
 rows=list(csv.reader(f));assert rows[0]==HEADERS and len(rows)==11
assert all(float(a[-1])==b[-1] for a,b in zip(rows[1:],ROWS))
print('OK: datos, particiones, promedio, errores, CSV y resultados reproducibles.')
