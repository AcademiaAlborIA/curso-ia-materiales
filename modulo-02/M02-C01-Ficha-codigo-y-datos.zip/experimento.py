"""Referencia constante para un caso didáctico. Solo biblioteca estándar."""
import csv,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ROWS=[
 ('H01','historico',1.2,2,0,20),('H02','historico',2.0,3,0,24),
 ('H03','historico',2.8,3,1,28),('H04','historico',3.5,5,0,32),
 ('H05','historico',4.2,6,1,36),('H06','historico',5.0,7,1,40),
 ('P01','comprobacion',1.0,2,0,20),('P02','comprobacion',3.0,4,0,30),
 ('P03','comprobacion',4.5,7,1,40),('P04','comprobacion',6.0,9,1,50)]
HEADERS=['pedido','grupo','distancia_km','pedidos_pendientes','lluvia_pronosticada','minutos_reales']
def ejecutar():
 historical=[r for r in ROWS if r[1]=='historico'];test=[r for r in ROWS if r[1]=='comprobacion']
 reference=sum(r[-1] for r in historical)/len(historical)
 cases=[dict(pedido=r[0],estimado=reference,real=r[-1],error_absoluto=abs(reference-r[-1])) for r in test]
 return dict(origen='Datos sintéticos, inventados para la lección',referencia_minutos=reference,historicos=len(historical),comprobacion=len(test),casos=cases,mae_minutos=sum(r['error_absoluto'] for r in cases)/len(cases),usa_caracteristicas=False)
if __name__=='__main__':
 with (ROOT/'pedidos.csv').open('w',encoding='utf-8',newline='') as f:
  w=csv.writer(f);w.writerow(HEADERS);w.writerows(ROWS)
 result=ejecutar();(ROOT/'resultados.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print('REFERENCIA: promedio de 6 pedidos historicos = 30 minutos')
 for row in result['casos']:print(f"{row['pedido']}: estimado {row['estimado']:.0f} | real {row['real']} | error {row['error_absoluto']:.0f} min")
 print(f"ERROR ABSOLUTO MEDIO: {result['mae_minutos']:.0f} minutos en 4 pedidos ficticios")
 print('No es un modelo que use distancia, cola o lluvia. No demuestra rendimiento real.')
