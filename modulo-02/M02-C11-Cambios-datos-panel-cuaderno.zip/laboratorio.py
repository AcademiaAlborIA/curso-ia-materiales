"""Calcula informes desde CSV y genera panel local autónomo."""
import argparse,json
from pathlib import Path
from monitor import ejecutar,guardar
P=Path(__file__).resolve().parent
def construir(folder=P):
 folder=Path(folder);results={}
 for key,file in [('a','control-a.csv'),('b','lote-b.csv'),('c','muestra-corta.csv')]:results[key]=ejecutar(folder/'referencia.csv',folder/file,folder/'reglas.json',folder/('informe-'+key))
 guardar(folder/'resultados-demo.json',results)
 html=(P/'panel-plantilla.html').read_text(encoding='utf-8').replace('__DATOS__',json.dumps(results,ensure_ascii=False,allow_nan=False).replace('</','<\\/'))
 (folder/'panel.html').write_text(html,encoding='utf-8');print('PANEL GENERADO:panel.html; no modelos entrenados ni etiquetas leídas.');return results
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--carpeta',type=Path,default=P);a=p.parse_args();construir(a.carpeta)
