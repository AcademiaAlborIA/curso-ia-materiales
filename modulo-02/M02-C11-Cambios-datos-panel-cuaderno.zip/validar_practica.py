"""Comprueba denominadores, reglas y extremos sin etiquetas ni entrenamiento."""
import csv,json,tempfile
from pathlib import Path
from monitor import comparar,leer,resumen,validar,sha,guardar
P=Path(__file__).resolve().parent;rules=json.loads((P/'reglas.json').read_text());before=sha(P/'referencia.csv')
a=comparar(P/'referencia.csv',P/'control-a.csv',rules);b=comparar(P/'referencia.csv',P/'lote-b.csv',rules);c=comparar(P/'referencia.csv',P/'muestra-corta.csv',rules);n=comparar(P/'referencia.csv',P/'todo-ausente.csv',rules)
assert a['referencia']==a['lote'] and a['alerta_ausentes'] is False and a['alerta_mas7'] is False
assert b['recibidas']==26 and b['rechazadas']==2 and b['lote']['validas']==24
assert b['referencia']['ausentes_distancia']==5 and b['referencia']['distancias_observadas']==19 and b['referencia']['intervalos']==[8,8,3]
assert b['lote']['ausentes_distancia']==12 and b['lote']['distancias_observadas']==12 and b['lote']['intervalos']==[0,0,12]
assert abs(b['delta_ausentes_pp']-29.166666666666664)<1e-8 and abs(b['delta_mas7_pp']-84.21052631578947)<1e-8
assert b['alerta_ausentes'] and b['alerta_mas7'] and b['exactitud'] is None
assert c['alerta_ausentes'] is None and c['alerta_mas7'] is None and not c['muestra_suficiente']
assert n['lote']['fraccion_mas7'] is None and n['alerta_mas7'] is None and n['alerta_ausentes'] is True
rows,_=validar(leer(P/'lote-b.csv'));imputed=[{**r,'distancia_km':3.7 if r['distancia_km'] is None else r['distancia_km']} for r in rows];assert resumen(imputed)['ausentes_distancia']==0
assert before==sha(P/'referencia.csv')
# Equality to threshold does not trigger:strictly greater than.
eq={**rules,'cambio_ausentes_pp':abs(b['delta_ausentes_pp']),'cambio_mas7_pp':abs(b['delta_mas7_pp'])};t=comparar(P/'referencia.csv',P/'lote-b.csv',eq);assert t['alerta_ausentes'] is False and t['alerta_mas7'] is False
with tempfile.TemporaryDirectory(dir=P) as td:
 f=Path(td)/'solo-invalidas.csv';f.write_text('id,distancia_km,pedidos_pendientes\nX,-2,3\n',encoding='utf-8');z=comparar(P/'referencia.csv',f,rules);assert z['lote']['validas']==0 and z['delta_ausentes_pp'] is None and z['alerta_ausentes'] is None
 f=Path(td)/'modificado.csv';changed=leer(P/'lote-b.csv');changed[12]['distancia_km']='2'
 with f.open('w',encoding='utf-8',newline='') as out:
  w=csv.DictWriter(out,fieldnames=['id','distancia_km','pedidos_pendientes']);w.writeheader();w.writerows(changed)
 z=comparar(P/'referencia.csv',f,rules);assert z['lote']['intervalos']==[1,0,11] and z['lote']['ausentes_distancia']==12
guardar(P/'verificacion-practica.json',dict(csv_read=True,reference_unchanged=True,reference_counts=[8,8,3],current_counts=[0,0,12],received=26,valid=24,rejected=2,missing=[5,12],missing_denominators=[24,24],observed_denominators=[19,12],delta_missing_pp=b['delta_ausentes_pp'],delta_far_pp=b['delta_mas7_pp'],short_sample_not_evaluated=True,all_missing_handled=True,zero_valid_handled=True,strict_threshold_verified=True,post_imputation_missing_zero=True,no_accuracy_claim=True))
print('VERIFICADO:26=24+2;ausentes5/24→12/24;>7km3/19→12/12;sin etiquetas ni fit.')
