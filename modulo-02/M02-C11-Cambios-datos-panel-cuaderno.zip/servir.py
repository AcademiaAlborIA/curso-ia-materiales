"""Solo sirve panel.html en127.0.0.1; no publica archivos ni recibe datos."""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import argparse
P=Path(__file__).resolve().parent
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_GET(self):
  if self.path!='/':self.send_error(404);return
  b=(P/'panel.html').read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--puerto',type=int,default=8767);a=p.parse_args();s=ThreadingHTTPServer(('127.0.0.1',a.puerto),Handler);print(f'PANEL LOCAL:http://127.0.0.1:{s.server_port}',flush=True)
 try:s.serve_forever()
 except KeyboardInterrupt:pass
 finally:s.server_close()
