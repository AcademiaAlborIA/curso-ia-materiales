"""Comparación descriptiva ANTES de imputar. Reglas didácticas, sin etiquetas ni fit."""
import argparse,csv,hashlib,json,math,statistics
from pathlib import Path
FEATURES=['distancia_km','pedidos_pendientes']
def guardar(p,obj):Path(p).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def leer(p):
 with Path(p).open(encoding='utf-8',newline='') as f:
  r=csv.DictReader(f)
  if r.fieldnames!=['id',*FEATURES]:raise ValueError('Columnas esperadas:id,distancia_km,pedidos_pendientes; no etiquetas')
  return list(r)
def validar(rows):
 valid=[];errors=[];seen=set()
 for row in rows:
  try:
   if not row.get('id','').strip() or row['id'] in seen:raise ValueError('id vacío o repetido')
   seen.add(row['id']);a={'id':row['id']}
   for key in FEATURES:
    s=row.get(key)
    if s is None:raise ValueError('Fila incompleta')
    s=s.strip()
    if not s:a[key]=None;continue
    try:v=float(s)
    except (ValueError,TypeError):raise ValueError(key+': se espera número')
    if not math.isfinite(v) or v<0:raise ValueError(key+': valor no finito o negativo')
    if key=='pedidos_pendientes' and not v.is_integer():raise ValueError(key+': se espera entero')
    a[key]=v
   valid.append(a)
  except ValueError as e:errors.append({'id':row.get('id','?'),'motivo':str(e)})
 return valid,errors
def resumen(rows):
 n=len(rows);v=[r['distancia_km'] for r in rows if r['distancia_km'] is not None];m=n-len(v);bins=[sum(x<=3 for x in v),sum(3<x<=7 for x in v),sum(x>7 for x in v)]
 return dict(validas=n,distancias_observadas=len(v),ausentes_distancia=m,tasa_ausentes=m/n if n else None,intervalos=bins,fraccion_mas7=bins[2]/len(v) if v else None,mediana_distancia=statistics.median(v) if v else None,ausentes_pendientes=sum(r['pedidos_pendientes'] is None for r in rows))
def comparar(referencia,lote,reglas):
 ref_rows,ref_bad=validar(leer(referencia));rows,bad=validar(leer(lote))
 if ref_bad or not ref_rows:raise ValueError('Referencia vacía o inválida: corrígela antes de comparar')
 a=resumen(ref_rows);b=resumen(rows)
 enough=min(a['validas'],b['validas'])>=reglas['minimo_filas_validas']
 enough_obs=min(a['distancias_observadas'],b['distancias_observadas'])>=reglas['minimo_distancias_observadas']
 delta_missing=100*(b['tasa_ausentes']-a['tasa_ausentes']) if b['tasa_ausentes'] is not None else None
 delta_far=100*(b['fraccion_mas7']-a['fraccion_mas7']) if b['fraccion_mas7'] is not None else None
 missing_flag=abs(delta_missing)>reglas['cambio_ausentes_pp'] if enough else None
 far_flag=abs(delta_far)>reglas['cambio_mas7_pp'] if enough and enough_obs else None
 return dict(referencia=a,lote=b,recibidas=len(rows)+len(bad),rechazadas=len(bad),errores=bad,delta_ausentes_pp=delta_missing,delta_mas7_pp=delta_far,reglas=reglas,alerta_ausentes=missing_flag,alerta_mas7=far_flag,muestra_suficiente=enough,observadas_suficientes=enough_obs,sha256_referencia=sha(referencia),sha256_lote=sha(lote),etiquetas_disponibles=False,exactitud=None,interpretacion='Señal descriptiva para investigar; no prueba de fallo, causa ni cambio de relación entrada-salida.')
def ejecutar(ref,lote,reglas_path,salida):
 rules=json.loads(Path(reglas_path).read_text(encoding='utf-8'))
 if set(rules)!={'minimo_filas_validas','minimo_distancias_observadas','cambio_ausentes_pp','cambio_mas7_pp'}:raise ValueError('Reglas incompletas o desconocidas')
 for k,v in rules.items():
  if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0:raise ValueError('Regla inválida')
 if rules['minimo_filas_validas']<1 or rules['minimo_distancias_observadas']<1:raise ValueError('Mínimos deben ser positivos')
 r=comparar(ref,lote,rules);out=Path(salida);out.mkdir(exist_ok=True,parents=True);guardar(out/'informe.json',r)
 print(Path(lote).name,': recibidas',r['recibidas'],'válidas',r['lote']['validas'],'rechazadas',r['rechazadas'])
 print('Ausentes distancia:',r['referencia']['ausentes_distancia'],'/',r['referencia']['validas'],'->',r['lote']['ausentes_distancia'],'/',r['lote']['validas'],'delta pp',round(r['delta_ausentes_pp'],2) if r['delta_ausentes_pp'] is not None else 'sin dato')
 print('Más de7km:',r['referencia']['intervalos'][2],'/',r['referencia']['distancias_observadas'],'->',r['lote']['intervalos'][2],'/',r['lote']['distancias_observadas'])
 print('Alertas ausentes/distancia:',r['alerta_ausentes'],r['alerta_mas7'],'Exactitud:no disponible,sin etiquetas.');return r
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--referencia',type=Path,default=Path(__file__).resolve().parent/'referencia.csv');p.add_argument('--lote',type=Path,default=Path(__file__).resolve().parent/'lote-b.csv');p.add_argument('--reglas',type=Path,default=Path(__file__).resolve().parent/'reglas.json');p.add_argument('--salida',type=Path,default=Path(__file__).resolve().parent/'mi-informe');a=p.parse_args();ejecutar(a.referencia,a.lote,a.reglas,a.salida)
