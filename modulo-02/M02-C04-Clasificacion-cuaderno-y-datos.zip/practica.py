"""Árbol de clasificación reproducible. Pedidos ficticios, partición fijada antes del ajuste."""
import argparse,csv,json
from pathlib import Path
import numpy as np
import sklearn
from sklearn.tree import DecisionTreeClassifier,export_text
from sklearn.dummy import DummyClassifier
from sklearn.metrics import accuracy_score,confusion_matrix

FEATURES=['distancia_km','pedidos_pendientes'];LABELS={0:'En plazo',1:'Retraso'};LIMIT=35
TRAIN_VALUES=[(1,1,18),(1.5,2,20),(2,3,23),(2.5,2,25),(3,4,28),(3.5,3,32),(4,4,35),(4.5,2,34),(2,5,33),(3,5,35),(2,7,42),(3,8,46),(4,7,48),(5,3,43),(5.5,4,47),(6,5,51),(6.5,6,55),(7,3,56)]
TEST_VALUES=[(1.8,2,22),(3.2,4,31),(5.2,3,45),(2.7,8,44),(3.8,4,49),(5.5,2,34),(4.2,5,35),(6.2,6,52)]
def records(values,group,prefix):return [dict(pedido=f'{prefix}{i+1:02}',grupo=group,distancia_km=d,pedidos_pendientes=p,minutos_reales=m,retraso=int(m>LIMIT)) for i,(d,p,m) in enumerate(values)]
ROWS=records(TRAIN_VALUES,'entrenamiento','E')+records(TEST_VALUES,'prueba','P')
def read_rows(path=None):
 if path is None:return [dict(r) for r in ROWS]
 with Path(path).open(encoding='utf-8',newline='') as f:items=list(csv.DictReader(f))
 result=[]
 for r in items:
  item={**r,'distancia_km':float(r['distancia_km']),'pedidos_pendientes':int(r['pedidos_pendientes']),'minutos_reales':float(r['minutos_reales']),'retraso':int(r['retraso'])}
  if item['retraso']!=int(item['minutos_reales']>LIMIT):raise ValueError('Etiqueta incompatible con el umbral de 35 minutos')
  if item['grupo'] not in ['entrenamiento','prueba'] or item['distancia_km']<0 or item['pedidos_pendientes']<0:raise ValueError('Fila inválida')
  result.append(item)
 if len({r['pedido'] for r in result})!=len(result):raise ValueError('Identificadores repetidos')
 return result
def path_for(model,values):
 result=[];node=0
 while model.tree_.feature[node]>=0:
  f=int(model.tree_.feature[node]);threshold=float(model.tree_.threshold[node]);left=values[f]<=threshold
  result.append(dict(node=node,feature=FEATURES[f],value=float(values[f]),threshold=threshold,condition=f'{FEATURES[f]} <= {threshold:g}',satisfied=bool(left)))
  node=int(model.tree_.children_left[node] if left else model.tree_.children_right[node])
 return result+[dict(node=node,prediction=int(model.classes_[np.argmax(model.tree_.value[node])]))]
def ejecutar(rows=None,query=(3.2,7)):
 rows=read_rows() if rows is None else rows;train=[r for r in rows if r['grupo']=='entrenamiento'];test=[r for r in rows if r['grupo']=='prueba']
 X=np.array([[r[f] for f in FEATURES] for r in train]);y=np.array([r['retraso'] for r in train]);Xt=np.array([[r[f] for f in FEATURES] for r in test]);yt=np.array([r['retraso'] for r in test])
 model=DecisionTreeClassifier(max_depth=2,random_state=7).fit(X,y);baseline=DummyClassifier(strategy='most_frequent').fit(X,y)
 pred=model.predict(Xt);base=baseline.predict(Xt)
 cases=[dict(**r,prediccion=int(p),referencia=int(b),acierto=bool(p==r['retraso'])) for r,p,b in zip(test,pred,base)]
 nodes=[]
 for n in range(model.tree_.node_count):
  f=int(model.tree_.feature[n]);nodes.append(dict(id=n,feature=FEATURES[f] if f>=0 else None,threshold=float(model.tree_.threshold[n]) if f>=0 else None,left=int(model.tree_.children_left[n]),right=int(model.tree_.children_right[n]),samples=int(model.tree_.n_node_samples[n]),prediction=int(model.classes_[np.argmax(model.tree_.value[n])])))
 result=dict(origen='Datos sintéticos nuevos; no son datos operativos ni los archivos de capítulos anteriores',features=FEATURES,label='retraso = int(minutos_reales > 35)',limite_minutos=LIMIT,classes=LABELS,train=train,test=test,train_counts={str(v):int((y==v).sum()) for v in [0,1]},baseline_class=int(base[0]),cases=cases,correct_model=int((pred==yt).sum()),correct_baseline=int((base==yt).sum()),accuracy_model=float(accuracy_score(yt,pred)),accuracy_baseline=float(accuracy_score(yt,base)),confusion=confusion_matrix(yt,pred,labels=[0,1]).tolist(),nodes=nodes,tree_text=export_text(model,feature_names=FEATURES),query=dict(features=list(query),prediction=int(model.predict([query])[0]),path=path_for(model,query)),training_ranges={f:[float(X[:,k].min()),float(X[:,k].max())] for k,f in enumerate(FEATURES)},configuration=dict(max_depth=2,random_state=7),version_sklearn=sklearn.__version__)
 return result,model,baseline
def write_csv(path,rows):
 with Path(path).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def exportar(folder,source=None,query=(3.2,7)):
 folder=Path(folder);folder.mkdir(exist_ok=True,parents=True);rows=read_rows(source);r,model,baseline=ejecutar(rows,query)
 if source is None:write_csv(folder/'pedidos-clasificacion.csv',rows)
 write_csv(folder/'predicciones.csv',r['cases']);(folder/'resultados.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');(folder/'reglas-arbol.txt').write_text(r['tree_text'],encoding='utf-8')
 print(f"Entrenamiento: {len(r['train'])} | Prueba: {len(r['test'])}; datos ficticios.")
 print('Etiqueta: 1 = Retraso (>35 min); 0 = En plazo (<=35 min).')
 print(f"Referencia: siempre {LABELS[r['baseline_class']]} | Aciertos: {r['correct_baseline']}/{len(r['test'])}")
 print('Árbol aprendido:');print(r['tree_text'].rstrip())
 for c in r['cases']:print(f"{c['pedido']}: real {LABELS[c['retraso']]} | predice {LABELS[c['prediccion']]} | {'OK' if c['acierto'] else 'ERROR'}")
 print(f"Árbol: {r['correct_model']}/{len(r['test'])} aciertos; exactitud {r['accuracy_model']:.0%}, solo esta prueba.")
 print(f"Matriz [real][predicho], orden [En plazo, Retraso]: {r['confusion']}")
 print(f"Consulta {query[0]:g} km, {query[1]} pendientes: {LABELS[r['query']['prediction']]} (sin resultado real).")
 return r
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--csv',type=Path);p.add_argument('--distancia',type=float,default=3.2);p.add_argument('--pendientes',type=int,default=7);p.add_argument('--salida',type=Path,default=Path(__file__).resolve().parent);args=p.parse_args()
 if args.distancia<0 or args.pendientes<0:p.error('La distancia y los pendientes deben ser no negativos')
 exportar(args.salida,args.csv,(args.distancia,args.pendientes))
