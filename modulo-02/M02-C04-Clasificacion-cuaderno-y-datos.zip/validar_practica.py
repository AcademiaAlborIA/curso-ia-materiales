"""Verifica resultados, fronteras, ruta e independencia del ajuste respecto de la prueba."""
import copy,json
from pathlib import Path
import numpy as np
from practica import ejecutar,read_rows,path_for,FEATURES,LIMIT
P=Path(__file__).resolve().parent;rows=read_rows(P/'pedidos-clasificacion.csv');r,model,baseline=ejecutar(rows)
assert FEATURES==['distancia_km','pedidos_pendientes'] and LIMIT==35
assert len(r['train'])==18 and len(r['test'])==8
assert set(x['pedido'] for x in r['train']).isdisjoint(x['pedido'] for x in r['test'])
assert r['train_counts']=={'0':10,'1':8} and r['baseline_class']==0
assert (r['correct_model'],r['correct_baseline'])==(6,4) and r['confusion']==[[3,1],[1,3]]
assert r['accuracy_model']==.75 and r['accuracy_baseline']==.5
assert {x['pedido'] for x in r['cases'] if not x['acierto']}=={'P05','P06'}
assert all(x['retraso']==int(x['minutos_reales']>35) for x in rows)
assert all(x['retraso']==0 for x in rows if x['minutos_reales']==35)
assert model.predict([[3.2,5],[3.2,7],[4.75,6],[4.76,6]]).tolist()==[0,1,0,1]
assert [x['node'] for x in path_for(model,[3.2,7])]==[0,1,3]
before=copy.deepcopy(model.tree_.__getstate__());model.predict([[3.2,3]]);after=model.tree_.__getstate__()
assert np.array_equal(before['nodes'],after['nodes']) and np.array_equal(before['values'],after['values'])
changed=copy.deepcopy(rows)
for x in changed:
 if x['grupo']=='prueba':x['minutos_reales']=60 if x['retraso']==0 else 20;x['retraso']=1-x['retraso']
other,other_model,_=ejecutar(changed)
assert np.array_equal(model.tree_.threshold,other_model.tree_.threshold) and np.array_equal(model.tree_.value,other_model.tree_.value)
saved=json.loads((P/'resultados.json').read_text(encoding='utf-8'))
for key in ['cases','correct_model','correct_baseline','confusion','nodes','train_counts']:assert saved[key]==r[key],key
print('OK: 18/8 separados, referencia 4/8, árbol 6/8, matriz [[3,1],[1,3]], dos errores, consultas y prueba fuera del ajuste.')
