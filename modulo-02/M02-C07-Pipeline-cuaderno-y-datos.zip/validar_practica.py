"""Verifica aislamiento de preparación, equivalencia manual y consultas sin reajuste."""
import copy
from pathlib import Path
import numpy as np
from sklearn.base import clone
from sklearn.model_selection import StratifiedKFold,cross_val_predict
import practica as p
rows=p.cargar();r=p.evaluar_cv(rows);X,y=p.arrays(r['desarrollo']);splits=list(StratifiedKFold(n_splits=3,shuffle=True,random_state=7).split(X,y))
assert len(rows)==32 and len(r['desarrollo'])==24
assert r['mini_demo']['mediana_correcta']==4 and r['mini_demo']['mediana_con_fuga']==6
assert [f['medianas'] for f in r['vueltas']]==[[4.2,2.5],[5.0,3.5],[3.5,3.5]]
assert [f['coste'] for f in r['vueltas']]==[11,10,5]
assert (r['oof']['aciertos'],r['oof']['coste'],r['diagnostico_con_fuga']['coste'])==(18,26,25)
assert all(f['manual_igual'] and f['n_columnas_salida']==4 and f['indicadores']==[0,1] for f in r['vueltas'])
coverage=[]
for f,(tr,va) in zip(r['vueltas'],splits):
 assert not set(f['ajuste'])&set(f['validacion']);assert len(f['ajuste'])==16 and len(f['validacion'])==8;coverage+=f['validacion']
 original=clone(p.pipeline()).fit(X[tr],y[tr]);changed=X.copy();changed[va]=1000;again=clone(p.pipeline()).fit(changed[tr],y[tr]);assert np.array_equal(original.named_steps['preparar'].statistics_,again.named_steps['preparar'].statistics_)
assert len(coverage)==len(set(coverage))==24
api=cross_val_predict(p.pipeline(),X,y,cv=splits);assert api.tolist()==[a['prediccion'] for a in r['casos_oof']]
altered=copy.deepcopy(rows)
for a in altered:
 if a['grupo']=='prueba':a['retraso']=1-a['retraso'];a['minutos_reales']=40 if a['retraso'] else 30;a['distancia_km']=999
assert p.evaluar_cv(altered)==r
model=p.ajuste_final(rows);before=model.named_steps['preparar'].statistics_.copy();query=p.consultar(model,[None,6]);assert query['transformada']==[4.5,6.,1.,0.] and query['categoria']=='En plazo'
other=p.consultar(model,[7,None]);assert other['transformada']==[7.,3.,0.,1.];assert np.array_equal(before,model.named_steps['preparar'].statistics_)
final=p.prueba_final(rows,model);assert final['matriz']==[[5,0],[3,0]] and final['coste']==15
folder=Path(__file__).resolve().parent/'verificacion-csv';folder.mkdir(exist_ok=True);p.csv_write(folder/'datos.csv',rows);loaded=p.cargar(folder/'datos.csv');assert sum(a['distancia_km'] is None for a in loaded)==7;assert sum(a['pedidos_pendientes'] is None for a in loaded)==6
assert p.evaluar_cv(loaded)['vueltas']==r['vueltas'];loaded[0]['distancia_km']+=.2;p.csv_write(folder/'alterados.csv',loaded);assert p.cargar(folder/'alterados.csv')[0]['distancia_km']==loaded[0]['distancia_km']
print('VERIFICADO: mediana4/6, preparación solo ajuste, manual=Pipeline=API, indicadores, predict sin fit, CSV y prueba aparte.')
