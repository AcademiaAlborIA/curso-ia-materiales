"""Pipeline reproducible: imputar dentro de cada vuelta y predecir sin reajustar."""
import argparse,csv,hashlib,json
from pathlib import Path
import numpy as np
import sklearn
from sklearn.base import clone
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import confusion_matrix
FEATURES=['distancia_km','pedidos_pendientes'];NOMBRES={0:'En plazo',1:'Retraso'}
def generar():
 rng=np.random.default_rng(2027);rows=[]
 for k in range(32):
  d=round(float(rng.uniform(1,8)),1);p=int(rng.integers(1,9));m=max(12,int(round(10+3*d+2*p+rng.normal(0,5))))
  rows.append(dict(pedido=('D' if k<24 else 'F')+f'{k+1 if k<24 else k-23:02}',grupo='desarrollo' if k<24 else 'prueba',distancia_km=None if k in [2,6,11,17,22,25,29] else d,pedidos_pendientes=None if k in [4,10,15,20,28,31] else p,minutos_reales=m,retraso=int(m>35)))
 return rows
def cargar(path=None):
 if path is None:return generar()
 with Path(path).open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
 for r in rows:
  for key in FEATURES:r[key]=None if r[key] in ['',None] else float(r[key])
  for key in ['minutos_reales','retraso']:r[key]=int(r[key])
  if r['retraso']!=int(r['minutos_reales']>35) or r['grupo'] not in ['desarrollo','prueba']:raise ValueError('Etiqueta o grupo inválido')
 if len({r['pedido'] for r in rows})!=len(rows):raise ValueError('Identificadores repetidos')
 return rows
def arrays(rows):return np.array([[np.nan if r[f] is None else r[f] for f in FEATURES] for r in rows]),np.array([r['retraso'] for r in rows])
def pipeline():return Pipeline([('preparar',SimpleImputer(strategy='median',add_indicator=True)),('modelo',DecisionTreeClassifier(max_depth=2,random_state=7))])
def medir(y,pred):
 tn,fp,fn,tp=map(int,confusion_matrix(y,pred,labels=[0,1]).ravel());return dict(n=len(y),tn=tn,fp=fp,fn=fn,tp=tp,matriz=[[tn,fp],[fn,tp]],aciertos=int((y==pred).sum()),coste=5*fn+fp)
def mini_demo():
 tr=np.array([[2.],[4.],[np.nan],[6.]]);va=np.array([[8.],[10.]])
 local=SimpleImputer(strategy='median').fit(tr);global_=SimpleImputer(strategy='median').fit(np.vstack([tr,va]))
 return dict(ajuste=[2,4,None,6],reservadas=[8,10],mediana_correcta=float(local.statistics_[0]),mediana_con_fuga=float(global_.statistics_[0]),relleno_correcto=float(local.transform([[np.nan]])[0,0]),relleno_con_fuga=float(global_.transform([[np.nan]])[0,0]))
def evaluar_cv(rows=None):
 rows=cargar() if rows is None else rows;dev=[r for r in rows if r['grupo']=='desarrollo'];X,y=arrays(dev);cv=StratifiedKFold(n_splits=3,shuffle=True,random_state=7);splits=list(cv.split(X,y));folds=[];oof=np.full(len(y),-1);global_imputer=SimpleImputer(strategy='median',add_indicator=True).fit(X);leaky=global_imputer.transform(X);bad_oof=np.full(len(y),-1)
 for f,(tr,va) in enumerate(splits):
  good=clone(pipeline()).fit(X[tr],y[tr]);pred=good.predict(X[va]);oof[va]=pred
  manual_pre=SimpleImputer(strategy='median',add_indicator=True).fit(X[tr]);manual_model=DecisionTreeClassifier(max_depth=2,random_state=7).fit(manual_pre.transform(X[tr]),y[tr]);assert np.array_equal(pred,manual_model.predict(manual_pre.transform(X[va])))
  bad=DecisionTreeClassifier(max_depth=2,random_state=7).fit(leaky[tr],y[tr]);bp=bad.predict(leaky[va]);bad_oof[va]=bp
  m=medir(y[va],pred);m.update(vuelta=f+1,ajuste=[dev[k]['pedido'] for k in tr],validacion=[dev[k]['pedido'] for k in va],medianas=good.named_steps['preparar'].statistics_.tolist(),indicadores=good.named_steps['preparar'].indicator_.features_.tolist(),n_columnas_salida=int(good.named_steps['preparar'].transform(X[tr]).shape[1]),manual_igual=True,coste_con_fuga=medir(y[va],bp)['coste']);folds.append(m)
 frozen=dict(configuracion='SimpleImputer(median, add_indicator=True) -> DecisionTreeClassifier(max_depth=2, random_state=7)',criterio='configuración prefijada; sin buscar la mejor media ni elegir por la comparación con fuga',cv='StratifiedKFold(3, shuffle=True, random_state=7)',coste_fn=5,coste_fp=1,huella_desarrollo=hashlib.sha256(json.dumps(dev,sort_keys=True).encode()).hexdigest())
 return dict(origen='32 pedidos nuevos ficticios, generador semilla2027. Ausentes programados para aprender; no se reutilizan pruebas previas.',features=FEATURES,desarrollo=dev,mini_demo=mini_demo(),vueltas=folds,oof=medir(y,oof),casos_oof=[dict(**r,prediccion=int(p)) for r,p in zip(dev,oof)],medianas_globales_incorrectas=global_imputer.statistics_.tolist(),diagnostico_con_fuga=medir(y,bad_oof),coste_medio=float(np.mean([f['coste'] for f in folds])),configuracion_congelada=frozen,version_sklearn=sklearn.__version__)
def ajuste_final(rows):
 dev=[r for r in rows if r['grupo']=='desarrollo'];X,y=arrays(dev);return pipeline().fit(X,y)
def consultar(modelo,entrada):
 X=np.array([[np.nan if v is None else v for v in entrada]],float);pre=modelo.named_steps['preparar'];antes=pre.statistics_.copy();transformada=pre.transform(X)[0];pred=int(modelo.predict(X)[0]);assert np.array_equal(antes,pre.statistics_)
 return dict(entrada=entrada,transformada=transformada.tolist(),indicadores=pre.indicator_.features_.tolist(),prediccion=pred,categoria=NOMBRES[pred],medianas_sin_cambiar=pre.statistics_.tolist())
def prueba_final(rows,modelo):
 test=[r for r in rows if r['grupo']=='prueba'];X,y=arrays(test);pred=modelo.predict(X);r=medir(y,pred);r.update(casos=[dict(**a,prediccion=int(p)) for a,p in zip(test,pred)]);return r
def csv_write(path,rows):
 with Path(path).open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def exportar(folder,source=None,abrir=False,entrada=None):
 folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);rows=cargar(source);r=evaluar_cv(rows);save=lambda name,obj:(folder/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
 if source is None:csv_write(folder/'pedidos-pipeline.csv',rows)
 save('configuracion-congelada.json',r['configuracion_congelada'])
 print('32 pedidos ficticios; desarrollo24/prueba8. Pipeline prefijado; coste FN5/FP1.')
 print('Mini-demo: mediana correcta4; mediana6 si se incluyen las reservadas8 y10.')
 for f in r['vueltas']:print(f"Vuelta {f['vuelta']}: medianas {f['medianas']} | aciertos {f['aciertos']}/8 | FN {f['fn']} FP {f['fp']} | coste {f['coste']} | manual=Pipeline")
 print(f"OOF: {r['oof']['aciertos']}/24 | coste {r['oof']['coste']} | coste medio {r['coste_medio']:.2f}")
 print('Diagnóstico incorrecto (preparar24 antes de CV):',r['medianas_globales_incorrectas'],'coste OOF',r['diagnostico_con_fuga']['coste'],'NO es candidato válido.')
 model=ajuste_final(rows);r['medianas_finales']=model.named_steps['preparar'].statistics_.tolist();r['consulta']=consultar(model,[None,6] if entrada is None else entrada);print('Consulta:',r['consulta'])
 if abrir:r['prueba_final']=prueba_final(rows,model);m=r['prueba_final'];print(f"PRUEBA: {m['aciertos']}/8 | FN {m['fn']} FP {m['fp']} | coste {m['coste']}");save('prueba-final.json',m)
 else:print('Prueba final NO evaluada. Abrir explícitamente con --prueba-final.')
 save('resultados.json',r);csv_write(folder/'predicciones-oof.csv',r['casos_oof']);return r
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--csv',type=Path);p.add_argument('--prueba-final',action='store_true');p.add_argument('--salida',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--consulta',nargs=2,metavar=('DISTANCIA','PENDIENTES'));a=p.parse_args()
 entrada=[None if v.lower() in ['na','none','?'] else float(v) for v in a.consulta] if a.consulta else None;exportar(a.salida,a.csv,a.prueba_final,entrada)
