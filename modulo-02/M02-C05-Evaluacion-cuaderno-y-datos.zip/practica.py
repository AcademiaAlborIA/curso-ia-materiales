"""Evaluación didáctica: métricas por clase, costes y selección antes de la prueba final."""
import argparse,csv,hashlib,json
from pathlib import Path
import numpy as np
import sklearn
from sklearn.tree import DecisionTreeClassifier
from sklearn.dummy import DummyClassifier
from sklearn.metrics import accuracy_score,confusion_matrix,precision_score,recall_score
FEATURES=['distancia_km','pedidos_pendientes'];LABELS={0:'En plazo',1:'Retraso'}
TRAIN_VALUES=[(1,1,18),(1.5,2,20),(2,3,23),(2.5,2,25),(3,4,28),(3.5,3,32),(4,4,35),(4.5,2,34),(2,5,33),(3,5,35),(2,7,42),(3,8,46),(4,7,48),(5,3,43),(5.5,4,47),(6,5,51),(6.5,6,55),(7,3,56)]
VAL_VALUES=[(1,1,19),(1.5,2,21),(2,3,24),(2.5,2,27),(3,4,29),(3.5,3,33),(4,4,35),(4.5,2,34),(2,5,32),(3,5,35),(1.8,2,22),(3.2,4,31),(4.2,5,35),(5.5,2,34),(2.5,7,30),(3.8,8,35),(5.3,3,43),(6.2,6,52),(2.7,8,44),(3.6,7,41)]
TEST_VALUES=[(1.2,1,20),(1.9,3,23),(2.6,4,28),(3.3,3,30),(3.9,5,34),(4.4,4,35),(2.2,2,25),(5.2,2,35),(5,3,44),(3.2,3,48)]
def records(values,group,prefix):return [dict(pedido=f'{prefix}{i+1:02}',grupo=group,distancia_km=d,pedidos_pendientes=p,minutos_reales=m,retraso=int(m>35)) for i,(d,p,m) in enumerate(values)]
ROWS=records(TRAIN_VALUES,'entrenamiento','E')+records(VAL_VALUES,'validacion','V')+records(TEST_VALUES,'prueba','F')
def read_rows(path=None):
 if path is None:return [dict(r) for r in ROWS]
 with Path(path).open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
 for r in rows:
  for key in ['distancia_km','minutos_reales']:r[key]=float(r[key])
  for key in ['pedidos_pendientes','retraso']:r[key]=int(r[key])
  if r['retraso']!=int(r['minutos_reales']>35) or r['grupo'] not in ['entrenamiento','validacion','prueba']:raise ValueError('Fila o etiqueta inválida')
 if len({r['pedido'] for r in rows})!=len(rows):raise ValueError('Identificadores repetidos')
 return rows
def arrays(rows):return np.array([[r[f] for f in FEATURES] for r in rows]),np.array([r['retraso'] for r in rows])
def evaluar(rows,pred,coste_fn=5,coste_fp=1):
 y=np.array([r['retraso'] for r in rows]);pred=np.array(pred,dtype=int);cm=confusion_matrix(y,pred,labels=[0,1]);tn,fp,fn,tp=map(int,cm.ravel())
 return dict(n=len(y),tn=tn,fp=fp,fn=fn,tp=tp,matriz=cm.tolist(),aciertos=int((y==pred).sum()),exactitud=float(accuracy_score(y,pred)),precision=float(precision_score(y,pred,zero_division=0)) if tp+fp else None,sensibilidad=float(recall_score(y,pred,zero_division=0)) if tp+fn else None,alertas=tp+fp,retrasos=tp+fn,coste=int(fn*coste_fn+fp*coste_fp),casos=[dict(**r,prediccion=int(p),tipo='VP' if r['retraso']==p==1 else 'VN' if r['retraso']==p==0 else 'FN' if r['retraso']==1 else 'FP') for r,p in zip(rows,pred)])
def seleccionar(rows=None,coste_fn=5,coste_fp=1):
 rows=read_rows() if rows is None else rows;train=[r for r in rows if r['grupo']=='entrenamiento'];val=[r for r in rows if r['grupo']=='validacion'];X,y=arrays(train);Xv,_=arrays(val)
 models={'Referencia':DummyClassifier(strategy='most_frequent'),'A':DecisionTreeClassifier(max_depth=1,random_state=7),'B':DecisionTreeClassifier(max_depth=2,random_state=7)}
 for m in models.values():m.fit(X,y)
 scores={name:evaluar(val,m.predict(Xv),coste_fn,coste_fp) for name,m in models.items()}
 order=['Referencia','A','B'];chosen=min(order,key=lambda n:(scores[n]['coste'],order.index(n)))
 digest=hashlib.sha256(json.dumps(train+val,sort_keys=True).encode()).hexdigest()
 frozen=dict(elegido=chosen,criterio='menor coste en validacion; empate: referencia, A, B',coste_fn=coste_fn,coste_fp=coste_fp,configuraciones=dict(Referencia='most_frequent',A={'max_depth':1,'random_state':7},B={'max_depth':2,'random_state':7}),huella_entrenamiento_y_validacion=digest)
 result=dict(origen='Datos ficticios deliberados: 18 de entrenamiento del capítulo 4, 20 nuevos de validación y 10 nuevos de prueba. No se reutilizan los ocho casos de prueba del capítulo 4.',features=FEATURES,train=train,validacion=val,metricas=scores,seleccion_congelada=frozen,version_sklearn=sklearn.__version__)
 return result,models
def ejecutar(rows=None,coste_fn=5,coste_fp=1,abrir_prueba=False):
 rows=read_rows() if rows is None else rows;r,models=seleccionar(rows,coste_fn,coste_fp)
 if abrir_prueba:
  test=[x for x in rows if x['grupo']=='prueba'];Xt,_=arrays(test);chosen=r['seleccion_congelada']['elegido'];r['prueba_final']=evaluar(test,models[chosen].predict(Xt),coste_fn,coste_fp)
 return r,models
def write_csv(path,rows):
 with Path(path).open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def exportar(folder,source=None,coste_fn=5,coste_fp=1,abrir_prueba=False):
 folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);rows=read_rows(source);r,models=seleccionar(rows,coste_fn,coste_fp)
 if source is None:write_csv(folder/'pedidos-evaluacion.csv',rows)
 (folder/'seleccion-congelada.json').write_text(json.dumps(r['seleccion_congelada'],ensure_ascii=False,indent=2),encoding='utf-8')
 counts={g:sum(x['grupo']==g for x in rows) for g in ['entrenamiento','validacion','prueba']}
 print(f"Entrenamiento {counts['entrenamiento']} | Validación {counts['validacion']} | Prueba final {counts['prueba']} (reservada para después de seleccionar).")
 print(f'Costes didácticos fijados: FN={coste_fn}, FP={coste_fp}; no son precios reales.')
 for name,m in r['metricas'].items():
  pr='sin alertas: no definida' if m['precision'] is None else f"{m['precision']:.1%}"
  print(f"{name}: aciertos {m['aciertos']}/{m['n']} | FP {m['fp']} | FN {m['fn']} | precisión {pr} | sensibilidad {m['sensibilidad']:.0%} | coste {m['coste']}")
 print('Elección congelada:',r['seleccion_congelada']['elegido'])
 if abrir_prueba:
  test=[x for x in rows if x['grupo']=='prueba'];Xt,_=arrays(test);chosen=r['seleccion_congelada']['elegido'];r['prueba_final']=evaluar(test,models[chosen].predict(Xt),coste_fn,coste_fp);m=r['prueba_final']
  print(f"PRUEBA FINAL de {chosen}: aciertos {m['aciertos']}/{m['n']} | FP {m['fp']} | FN {m['fn']} | sensibilidad {m['sensibilidad']:.0%} | coste {m['coste']}")
  (folder/'evaluacion-prueba-final.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
 else:print('Prueba final no evaluada. Para abrirla explícitamente: --prueba-final')
 (folder/'resultados.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
 for name,m in r['metricas'].items():write_csv(folder/f'validacion-{name}.csv',m['casos'])
 return r
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--csv',type=Path);p.add_argument('--coste-fn',type=int,default=5);p.add_argument('--coste-fp',type=int,default=1);p.add_argument('--prueba-final',action='store_true');p.add_argument('--salida',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args()
 if a.coste_fn<0 or a.coste_fp<0:p.error('Los costes deben ser no negativos')
 exportar(a.salida,a.csv,a.coste_fn,a.coste_fp,a.prueba_final)
