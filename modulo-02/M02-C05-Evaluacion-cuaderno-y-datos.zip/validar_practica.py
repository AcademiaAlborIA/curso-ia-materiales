"""Verifica las cuentas y que cambiar respuestas finales no altera la selección."""
import copy,tempfile
from pathlib import Path
import practica as p
r,models=p.ejecutar(abrir_prueba=True)
assert [sum(a['grupo']==g for a in p.ROWS) for g in ['entrenamiento','validacion','prueba']]==[18,20,10]
assert len({a['pedido'] for a in p.ROWS})==48
assert r['metricas']['Referencia']['matriz']==[[16,0],[4,0]]
assert r['metricas']['Referencia']['precision'] is None
assert r['metricas']['A']['matriz']==[[15,1],[2,2]]
assert r['metricas']['B']['matriz']==[[13,3],[0,4]]
assert [r['metricas'][n]['coste'] for n in ['Referencia','A','B']]==[20,11,3]
assert r['seleccion_congelada']['elegido']=='B'
assert r['prueba_final']['matriz']==[[7,1],[1,1]]
assert r['prueba_final']['precision']==r['prueba_final']['sensibilidad']==.5
assert r['prueba_final']['coste']==6
altered=copy.deepcopy(p.ROWS)
for row in altered:
 if row['grupo']=='prueba':row['retraso']=1-row['retraso'];row['minutos_reales']=50 if row['retraso'] else 25
a,am=p.ejecutar(altered,abrir_prueba=True)
assert a['seleccion_congelada']==r['seleccion_congelada']
assert a['prueba_final']['matriz']!=r['prueba_final']['matriz']
assert (models['B'].tree_.threshold==am['B'].tree_.threshold).all()
other,_=p.ejecutar(coste_fn=2,coste_fp=3)
assert [other['metricas'][n]['coste'] for n in ['Referencia','A','B']]==[8,7,9]
assert other['seleccion_congelada']['elegido']=='A' and 'prueba_final' not in other
folder=Path(__file__).resolve().parent/'verificacion-csv';folder.mkdir(exist_ok=True)
if True:
 path=Path(folder)/'datos.csv';p.write_csv(path,p.ROWS);loaded=p.read_rows(path)
 test,_=p.ejecutar(loaded,abrir_prueba=True)
 assert test['prueba_final']['matriz']==r['prueba_final']['matriz']
 assert next(x for x in loaded if x['pedido']=='F08')['retraso']==0
print('VERIFICADO: matrices, costes, CSV, límite de 35 min y selección ajena a las respuestas finales.')
