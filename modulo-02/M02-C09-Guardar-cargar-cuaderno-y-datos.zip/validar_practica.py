"""Carga en proceso separado sin CSV, sin entrenar.py y con fit bloqueado."""
import copy,json,os,shutil,subprocess,sys,uuid
from pathlib import Path
import joblib,numpy as np
from comun import guardar_json,leer_json,sha,validar_consultas
from entrenar import entrenar
from predecir import predecir
P=Path(__file__).resolve().parent;folder=P/'verificacion-procesos'/uuid.uuid4().hex;folder.mkdir(parents=True)
env={**os.environ,'PYTHONIOENCODING':'utf-8'}
entrenar(P/'entrenamiento-desarrollo.csv',P/'consultas.json',folder/'artefactos')
for name in ['predecir.py','comun.py','consultas.json']:shutil.copy2(P/name,folder/name)
assert not (folder/'entrenar.py').exists() and not list(folder.glob('*.csv'))
before_model=sha(folder/'artefactos/modelo-entregas-v1.joblib');before_meta=sha(folder/'artefactos/metadata.json')
program='''import runpy,sys
from sklearn.impute import SimpleImputer
from sklearn.tree import DecisionTreeClassifier
def prohibido(*a,**kw):raise AssertionError("fit no debe ejecutarse al cargar/predecir")
SimpleImputer.fit=prohibido
DecisionTreeClassifier.fit=prohibido
sys.argv=["predecir.py","--modelo","artefactos","--entrada","consultas.json","--salida","cargadas.json"]
runpy.run_path("predecir.py",run_name="__main__")
'''
r=subprocess.run([sys.executable,'-c',program],cwd=folder,env=env,capture_output=True,text=True,encoding='utf-8');assert r.returncode==0,r.stderr
after=leer_json(folder/'cargadas.json');before=leer_json(folder/'artefactos/referencia-antes.json');assert before==after['predicciones'] and len(before)==6
assert before_model==sha(folder/'artefactos/modelo-entregas-v1.joblib') and before_meta==sha(folder/'artefactos/metadata.json')
queries=leer_json(P/'consultas.json');reordered=[dict(reversed(list(a.items()))) for a in queries];guardar_json(folder/'reordenadas.json',reordered);rr=predecir(folder/'artefactos',folder/'reordenadas.json',folder/'reordenadas-pred.json');assert rr['predicciones']==before
assert np.isnan(validar_consultas(queries)[0,0])
bad=copy.deepcopy(queries);bad[0]['distancia_km']='tres kilómetros';guardar_json(folder/'incorrecta.json',bad)
rc=subprocess.run([sys.executable,'predecir.py','--modelo','artefactos','--entrada','incorrecta.json','--salida','rechazada.json'],cwd=folder,env=env,capture_output=True,text=True,encoding='utf-8');assert rc.returncode==2 and 'ERROR:' in rc.stderr and not (folder/'rechazada.json').exists()
for key,value in [('distancia_km',-1),('pedidos_pendientes',2.5),('distancia_km',True),('distancia_km',float('nan'))]:
 b=copy.deepcopy(queries);b[0][key]=value
 try:validar_consultas(b)
 except ValueError:pass
 else:raise AssertionError('Entrada inválida no rechazada')
meta=leer_json(folder/'artefactos/metadata.json');original_load=joblib.load
def no_cargar(*a,**kw):raise AssertionError('Se intentó cargar antes de validar ficha/huella')
joblib.load=no_cargar
try:
 for field,value in [('features',['pedidos_pendientes','distancia_km']),('versiones',{'scikit-learn':'otra'}),('sha256_modelo','0'*64)]:
  b=copy.deepcopy(meta);b[field]=value;guardar_json(folder/'artefactos/metadata.json',b)
  try:predecir(folder/'artefactos',P/'consultas.json',folder/'no-debe-existir.json')
  except ValueError:pass
  else:raise AssertionError('Se aceptó metadata incompatible')
finally:joblib.load=original_load;guardar_json(folder/'artefactos/metadata.json',meta)
evidence=dict(dos_procesos=True,sin_csv_historico=True,sin_script_entrenamiento=True,fit_bloqueado=True,coincidencias=6,transformaciones_iguales=True,artefacto_y_metadata_sin_cambios=True,claves_reordenadas_aceptadas=True,entrada_invalida_rechazada=True,versiones_contrato_huella_comprobados_antes_de_cargar=True,interpretacion='Reproducción, no exactitud; consultas sin etiquetas.')
guardar_json(P/'verificacion-practica.json',evidence);print('VERIFICADO:6/6 reproducidas en otro proceso, sin CSV/fit; contrato, versiones e integridad comprobados.')
