"""Proceso B: carga un artefacto propio, valida contrato y predice sin fit ni CSV histórico."""
import argparse,sys
from pathlib import Path
import joblib
from comun import FEATURES,versiones,sha,leer_json,guardar_json,validar_consultas,consultar
def predecir(folder,entrada,salida):
 folder=Path(folder);rows=leer_json(entrada);validar_consultas(rows);metadata=leer_json(folder/'metadata.json')
 if metadata.get('version_artefacto')!='v1' or metadata.get('features')!=FEATURES:raise ValueError('Contrato de columnas/versión de artefacto incompatible')
 if metadata.get('versiones')!=versiones():raise ValueError('Las versiones difieren de las registradas; regenera tu artefacto en este entorno')
 path=folder/'modelo-entregas-v1.joblib'
 if sha(path)!=metadata.get('sha256_modelo'):raise ValueError('La huella no coincide con metadata; no se carga el archivo')
 # joblib puede ejecutar código al cargar: usar únicamente artefactos propios o confiables.
 pipe=joblib.load(path);pred=consultar(pipe,rows);result=dict(proceso='B: cargar y predecir',entrenamiento_ejecutado=False,filas_historicas_leidas=0,consultas=len(rows),medianas_cargadas=pipe.named_steps['preparar'].statistics_.tolist(),sha256_modelo=sha(path),versiones=versiones(),predicciones=pred);guardar_json(salida,result)
 print('PROCESO B: cargado pipeline completo; sin fit y sin leer CSV histórico.')
 for r in pred:print(r['id'],r['transformada'],'->',r['categoria'])
 print('Medianas conservadas:',result['medianas_cargadas']);return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--modelo',type=Path,default=Path(__file__).resolve().parent/'artefactos');p.add_argument('--entrada',type=Path,default=Path(__file__).resolve().parent/'consultas.json');p.add_argument('--salida',type=Path,default=Path(__file__).resolve().parent/'predicciones-cargadas.json');a=p.parse_args()
 try:predecir(a.modelo,a.entrada,a.salida)
 except (ValueError,FileNotFoundError,KeyError) as err:print('ERROR:',err,file=sys.stderr);sys.exit(2)
