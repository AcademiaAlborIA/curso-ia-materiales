"""Búsqueda acotada en desarrollo, preparación dentro de CV y prueba aparte."""
import argparse,csv,hashlib,json
from pathlib import Path
import numpy as np
import sklearn
from sklearn.base import clone
from sklearn.dummy import DummyClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import GridSearchCV,StratifiedKFold,ParameterGrid
from sklearn.metrics import confusion_matrix,make_scorer
FEATURES=['distancia_km','pedidos_pendientes'];NOMBRES={0:'En plazo',1:'Retraso'}
def generar():
 rng=np.random.default_rng(2028);rows=[]
 for k in range(32):
  d=round(float(rng.uniform(1,8)),1);p=int(rng.integers(1,9));m=max(12,int(round(10+3*d+2*p+rng.normal(0,5))))
  rows.append(dict(pedido=('D' if k<24 else 'F')+f'{k+1 if k<24 else k-23:02}',grupo='desarrollo' if k<24 else 'prueba',distancia_km=None if k in [2,6,11,17,22,25,29] else d,pedidos_pendientes=None if k in [4,10,15,20,28,31] else p,minutos_reales=m,retraso=int(m>35)))
 return rows
def cargar(path=None):
 if path is None:return generar()
 with Path(path).open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
 for r in rows:
  for key in FEATURES:r[key]=None if r[key] in ['',None] else float(r[key])
  for key in ['minutos_reales','retraso']:r[key]=int(r[key])
  if r['retraso']!=int(r['minutos_reales']>35) or r['grupo'] not in ['desarrollo','prueba']:raise ValueError('Etiqueta o grupo inválido')
 if len({r['pedido'] for r in rows})!=len(rows):raise ValueError('Identificadores repetidos')
 return rows
def arrays(rows):return np.array([[np.nan if r[k] is None else r[k] for k in FEATURES] for r in rows]),np.array([r['retraso'] for r in rows])
def pipeline():return Pipeline([('preparar',SimpleImputer(strategy='median',add_indicator=True)),('modelo',DecisionTreeClassifier(random_state=7))])
def rejilla(reducida=False):return {'modelo__max_depth':[1,2] if reducida else [1,2,3],'modelo__min_samples_leaf':[1,3]}
def medir(y,pred):
 tn,fp,fn,tp=map(int,confusion_matrix(y,pred,labels=[0,1]).ravel());return dict(n=len(y),tn=tn,fp=fp,fn=fn,tp=tp,matriz=[[tn,fp],[fn,tp]],aciertos=int((y==pred).sum()),coste=5*fn+fp)
def coste(y,pred):return medir(y,pred)['coste']
def scorer():return make_scorer(coste,greater_is_better=False)
def seleccionar(rows=None,reducida=False):
 rows=cargar() if rows is None else rows;dev=[r for r in rows if r['grupo']=='desarrollo'];X,y=arrays(dev);cv=StratifiedKFold(n_splits=3,shuffle=True,random_state=7);splits=list(cv.split(X,y));grid=rejilla(reducida)
 search=GridSearchCV(pipeline(),grid,scoring=scorer(),cv=splits,refit=True,n_jobs=1,error_score='raise',return_train_score=False).fit(X,y)
 cr=search.cv_results_;candidates=[]
 for k,params in enumerate(cr['params']):
  costs=[int(round(-float(cr[f'split{f}_test_score'][k]))) for f in range(3)]
  candidates.append(dict(id=f'C{k+1}',profundidad=params['modelo__max_depth'],minimo_hoja=params['modelo__min_samples_leaf'],parametros=params,costes=costs,coste_medio=float(-cr['mean_test_score'][k]),puntuacion_media=float(cr['mean_test_score'][k]),rango=int(cr['rank_test_score'][k])))
 base_costs=[]
 for tr,va in splits:
  base=DummyClassifier(strategy='most_frequent').fit(X[tr],y[tr]);base_costs.append(coste(y[va],base.predict(X[va])))
 winner=candidates[int(search.best_index_)];frozen=dict(elegido=winner['id'],parametros=search.best_params_,indice=int(search.best_index_),criterio='menor coste medio CV; empate: primera combinación en orden de ParameterGrid',grid=grid,cv='3 particiones estratificadas, shuffle=True, random_state=7',coste_fn=5,coste_fp=1,refit=True,huella_desarrollo=hashlib.sha256(json.dumps(dev,sort_keys=True).encode()).hexdigest())
 r=dict(origen='32 nuevos pedidos ficticios, generador semilla2028, ausentes programados; no se reutilizan pruebas previas.',features=FEATURES,desarrollo=dev,particiones=[dict(vuelta=f+1,ajuste=[dev[k]['pedido'] for k in tr],validacion=[dev[k]['pedido'] for k in va]) for f,(tr,va) in enumerate(splits)],rejilla=grid,candidatos=candidates,ganador=winner,referencia=dict(costes=base_costs,coste_medio=float(np.mean(base_costs))),ajustes_busqueda=len(candidates)*3,ajustes_reajuste=1,ajustes_referencia=3,medianas_reajuste=search.best_estimator_.named_steps['preparar'].statistics_.tolist(),seleccion_congelada=frozen,version_sklearn=sklearn.__version__)
 return r,search
def prueba_final(rows,search):
 test=[r for r in rows if r['grupo']=='prueba'];X,y=arrays(test);pred=search.predict(X);r=medir(y,pred);r['casos']=[dict(**a,prediccion=int(p)) for a,p in zip(test,pred)];return r
def consultar(search,entrada):
 X=np.array([[np.nan if v is None else v for v in entrada]],float);pre=search.best_estimator_.named_steps['preparar'];before=pre.statistics_.copy();p=int(search.predict(X)[0]);assert np.array_equal(before,pre.statistics_);return dict(entrada=entrada,transformada=pre.transform(X)[0].tolist(),prediccion=p,categoria=NOMBRES[p])
def csv_write(path,rows):
 with Path(path).open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def exportar(folder,source=None,abrir=False,reducida=False):
 folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);rows=cargar(source);r,search=seleccionar(rows,reducida);save=lambda name,obj:(folder/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
 if source is None:csv_write(folder/'pedidos-busqueda.csv',rows)
 save('seleccion-congelada.json',r['seleccion_congelada'])
 print('Desarrollo24 / prueba8; coste didáctico FN5/FP1; mismo pipeline en cada vuelta.')
 print(f"Rejilla: {len(r['candidatos'])} combinaciones x3 vueltas = {r['ajustes_busqueda']} ajustes CV +1 reajuste. Referencia:3 ajustes aparte.")
 for c in r['candidatos']:print(f"{c['id']}: profundidad {c['profundidad']} | hoja {c['minimo_hoja']} | costes {c['costes']} | media {c['coste_medio']:.2f} | score {c['puntuacion_media']:.2f}")
 print('Referencia: costes',r['referencia']['costes'],'media',r['referencia']['coste_medio'])
 print('Elegido:',r['ganador']['id'],r['seleccion_congelada']['parametros'],'score',search.best_score_)
 print('Refit ya ajustó el ganador con24, solo desarrollo. Medianas:',r['medianas_reajuste'])
 r['consulta']=consultar(search,[None,6]);print('Consulta:',r['consulta'])
 if abrir:r['prueba_final']=prueba_final(rows,search);m=r['prueba_final'];print(f"PRUEBA FINAL: {m['aciertos']}/8 | FN {m['fn']} FP {m['fp']} | coste {m['coste']}");save('prueba-final.json',m)
 else:print('Prueba final NO evaluada. Abrir explícitamente con --prueba-final.')
 save('resultados.json',r);csv_write(folder/'tabla-busqueda.csv',[dict(id=c['id'],profundidad=c['profundidad'],minimo_hoja=c['minimo_hoja'],coste_v1=c['costes'][0],coste_v2=c['costes'][1],coste_v3=c['costes'][2],coste_medio=c['coste_medio'],puntuacion_media=c['puntuacion_media'],rango=c['rango']) for c in r['candidatos']]);return r
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--csv',type=Path);p.add_argument('--prueba-final',action='store_true');p.add_argument('--reducida',action='store_true');p.add_argument('--salida',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args();exportar(a.salida,a.csv,a.prueba_final,a.reducida)
