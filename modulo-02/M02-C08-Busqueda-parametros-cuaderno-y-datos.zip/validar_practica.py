"""Cuenta ajustes, compara búsqueda manual/API y verifica reserva e inmutabilidad."""
import copy
from pathlib import Path
import numpy as np
from sklearn.base import clone
from sklearn.impute import SimpleImputer
from sklearn.model_selection import StratifiedKFold,ParameterGrid
import practica as p
rows=p.cargar();logs=[];original=SimpleImputer.fit
def spy(self,X,y=None,**kw):logs.append(np.asarray(X).copy());return original(self,X,y,**kw)
SimpleImputer.fit=spy
try:r,search=p.seleccionar(rows)
finally:SimpleImputer.fit=original
assert [len(a) for a in logs].count(16)==18 and [len(a) for a in logs].count(24)==1 and len(logs)==19
assert len(rows)==32 and len(r['desarrollo'])==24
assert [c['costes'] for c in r['candidatos']]==[[7,3,1],[7,3,1],[7,3,20],[7,3,15],[7,3,21],[7,7,15]]
assert r['ganador']['id']=='C1' and r['seleccion_congelada']['parametros']=={'modelo__max_depth':1,'modelo__min_samples_leaf':1}
assert r['candidatos'][0]['rango']==r['candidatos'][1]['rango']==1
X,y=p.arrays(r['desarrollo']);splits=list(StratifiedKFold(n_splits=3,shuffle=True,random_state=7).split(X,y));cover=[]
for f,(tr,va) in zip(r['particiones'],splits):
 assert not set(f['ajuste'])&set(f['validacion']) and len(tr)==16 and len(va)==8;cover+=f['validacion']
assert len(cover)==len(set(cover))==24
for params,c in zip(ParameterGrid(p.rejilla()),r['candidatos']):
 manual=[]
 for tr,va in splits:
  m=clone(p.pipeline()).set_params(**params).fit(X[tr],y[tr]);manual.append(p.coste(y[va],m.predict(X[va])))
 assert manual==c['costes'];assert abs(-np.mean(manual)-c['puntuacion_media'])<1e-9
altered=copy.deepcopy(rows)
for a in altered:
 if a['grupo']=='prueba':a['retraso']=1-a['retraso'];a['minutos_reales']=40 if a['retraso'] else 30;a['distancia_km']=999
changed,_=p.seleccionar(altered);assert changed==r
pre=search.best_estimator_.named_steps['preparar'];before=pre.statistics_.copy();query=p.consultar(search,[None,6]);assert query['transformada']==[3.7,6.,1.,0.] and query['categoria']=='Retraso';assert np.array_equal(before,pre.statistics_)
final=p.prueba_final(rows,search);assert final['matriz']==[[4,2],[0,2]] and final['coste']==2
small,sm=p.seleccionar(rows,True);assert len(small['candidatos'])==4 and small['ajustes_busqueda']==12 and small['ganador']['id']=='C1';assert 'prueba_final' not in small
folder=Path(__file__).resolve().parent/'verificacion-csv';folder.mkdir(exist_ok=True);p.csv_write(folder/'datos.csv',rows);loaded=p.cargar(folder/'datos.csv');assert p.seleccionar(loaded)[0]['candidatos']==r['candidatos'];loaded[0]['distancia_km']+=.2;p.csv_write(folder/'alterados.csv',loaded);assert p.cargar(folder/'alterados.csv')[0]['distancia_km']==loaded[0]['distancia_km']
print('VERIFICADO:19 fits de preparación, manual=GridSearchCV, signo, empate, prueba fuera, consulta inmutable y rejilla reducida.')
