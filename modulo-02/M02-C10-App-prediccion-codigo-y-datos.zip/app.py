"""App LOCAL didáctica: cargar una vez un pipeline propio y consultar sin fit."""
import argparse,json,threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import joblib
from comun import FEATURES,versiones,sha,leer_json,consultar
P=Path(__file__).resolve().parent
class Servicio:
 def __init__(self,folder):
  folder=Path(folder);m=leer_json(folder/'metadata.json');path=folder/'modelo-entregas-v1.joblib'
  if m.get('version_artefacto')!='v1' or m.get('features')!=FEATURES:raise ValueError('Contrato del artefacto incompatible')
  if m.get('versiones')!=versiones():raise ValueError('Versiones diferentes: genera el artefacto en este entorno')
  if sha(path)!=m.get('sha256_modelo'):raise ValueError('Huella del modelo incompatible')
  # Solo artefactos propios/confiables: joblib.load puede ejecutar código.
  self.pipe=joblib.load(path);self.ficha=m;self.cargas=1;self.predicciones=0;self.lock=threading.Lock()
 def responder(self,consulta):
  with self.lock:
   r=consultar(self.pipe,[consulta])[0];self.predicciones+=1
  return dict(categoria=r['categoria'],entrada=r['entrada'],transformada=r['transformada'],version='v1',aviso='Estimación didáctica, no promesa de entrega. No conocemos el resultado real de esta consulta.',ausentes=[k for k in FEATURES if consulta[k] is None])
def crear_servidor(folder,puerto=8765):
 servicio=Servicio(folder)
 class Handler(BaseHTTPRequestHandler):
  def log_message(self,*a):pass
  def enviar(self,status,body,tipo='application/json; charset=utf-8'):
   b=body if isinstance(body,bytes) else json.dumps(body,ensure_ascii=False,allow_nan=False).encode('utf-8');self.send_response(status);self.send_header('Content-Type',tipo);self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(b)
  def do_GET(self):
   if self.path in ['/', '/app.js','/estilo.css']:
    name={'/':'index.html','/app.js':'app.js','/estilo.css':'estilo.css'}[self.path];tipo={'/':'text/html','/app.js':'text/javascript','/estilo.css':'text/css'}[self.path]
    self.enviar(200,(P/name).read_bytes(),tipo+'; charset=utf-8')
   else:self.enviar(404,dict(error='Ruta no disponible'))
  def do_POST(self):
   if self.path!='/predecir':self.enviar(404,dict(error='Ruta no disponible'));return
   origin=self.headers.get('Origin');expected=f'http://127.0.0.1:{self.server.server_port}'
   if origin and origin!=expected:self.enviar(403,dict(error='Origen no permitido'));return
   try:
    n=int(self.headers.get('Content-Length','0'))
    if not 0<n<=4096:raise ValueError('Tamaño de consulta inválido')
    if self.headers.get_content_type()!='application/json':raise ValueError('La consulta debe ser JSON')
    consulta=json.loads(self.rfile.read(n));result=servicio.responder(consulta)
   except (ValueError,TypeError,UnicodeDecodeError):
    self.enviar(400,dict(error='Revisa los datos: distancia numérica no negativa y pendientes enteros no negativos. Para ausentes, marca No disponible.'));return
   self.enviar(200,result)
 server=ThreadingHTTPServer(('127.0.0.1',puerto),Handler);server.servicio=servicio;return server
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--modelo',type=Path,default=P/'artefactos');p.add_argument('--puerto',type=int,default=8765);a=p.parse_args()
 server=crear_servidor(a.modelo,a.puerto)
 print(f'APP LOCAL: http://127.0.0.1:{server.server_port}',flush=True);print('Pipeline propio cargado una vez. Consultar usa predict, sin fit. Ctrl+C para cerrar.',flush=True)
 try:server.serve_forever()
 except KeyboardInterrupt:pass
 finally:server.server_close()
