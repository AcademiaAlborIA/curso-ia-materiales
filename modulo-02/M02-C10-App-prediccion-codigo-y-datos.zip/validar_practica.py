"""Pruebas de integración HTTP: mismo pipeline, errores visibles y sin reentrenar."""
import json,threading,urllib.request,urllib.error
from pathlib import Path
from sklearn.impute import SimpleImputer
from sklearn.tree import DecisionTreeClassifier
from comun import sha,guardar_json
from entrenar import entrenar
from app import crear_servidor
P=Path(__file__).resolve().parent
entrenar(P/'entrenamiento-desarrollo.csv',P/'consultas.json',P/'artefactos')
path=P/'artefactos/modelo-entregas-v1.joblib';before=sha(path)
def prohibido(*a,**kw):raise AssertionError('La app no debe entrenar')
SimpleImputer.fit=prohibido;DecisionTreeClassifier.fit=prohibido
server=crear_servidor(P/'artefactos',0);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();url=f'http://127.0.0.1:{server.server_port}'
def post(obj):
 req=urllib.request.Request(url+'/predecir',data=json.dumps(obj).encode(),headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req) as r:return r.status,json.load(r)
 except urllib.error.HTTPError as e:return e.code,json.load(e)
evidence=[]
try:
 with urllib.request.urlopen(url) as r:assert 'Tu primera app' in r.read().decode()
 for ident,d,p,category in [('A',2,7,'En plazo'),('B',7,2,'Retraso'),('C',None,6,'Retraso')]:
  status,r=post(dict(id=ident,distancia_km=d,pedidos_pendientes=p));assert status==200 and r['categoria']==category;evidence.append(dict(id=ident,http=status,**r))
 counts=server.servicio.predicciones
 for ident,d,p in [('NEG',-2,6),('FRAC',2,2.5),('TEXT','tres kilómetros',6),('BOOL',True,6)]:
  status,r=post(dict(id=ident,distancia_km=d,pedidos_pendientes=p));assert status==400 and 'error' in r and 'categoria' not in r;evidence.append(dict(id=ident,http=status,**r))
 assert server.servicio.predicciones==counts and counts==3 and server.servicio.cargas==1
 assert before==sha(path) and server.servicio.pipe.named_steps['preparar'].statistics_.tolist()==[3.7,3.0]
 guardar_json(P/'resultados-http.json',evidence);guardar_json(P/'verificacion-practica.json',dict(http_real=True,valid_queries=3,rejected_queries=4,loads=1,fit_blocked=True,model_unchanged=True,medians_unchanged=True,no_accuracy_claim=True))
 print('HTTP VERIFICADO:3 consultas,4 rechazos,carga1,fit bloqueado y archivo intacto.')
finally:server.shutdown();server.server_close()
