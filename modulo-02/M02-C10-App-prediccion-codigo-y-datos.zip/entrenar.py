"""Proceso A: reconstruye la configuración elegida en C08 y guarda el pipeline completo."""
import argparse,csv
from pathlib import Path
import joblib,numpy as np
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.tree import DecisionTreeClassifier
from comun import FEATURES,versiones,sha,guardar_json,leer_json,consultar
def entrenar(datos,consultas,salida):
 datos=Path(datos);folder=Path(salida);folder.mkdir(parents=True,exist_ok=True)
 with datos.open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
 if not rows or any(r['grupo']!='desarrollo' for r in rows):raise ValueError('El archivo debe contener solo las filas de desarrollo de C08')
 X=np.array([[np.nan if r[k]=='' else float(r[k]) for k in FEATURES] for r in rows]);y=np.array([int(r['retraso']) for r in rows])
 if any(int(r['retraso'])!=int(float(r['minutos_reales'])>35) for r in rows):raise ValueError('Etiqueta incoherente')
 pipe=Pipeline([('preparar',SimpleImputer(strategy='median',add_indicator=True)),('modelo',DecisionTreeClassifier(max_depth=1,min_samples_leaf=1,random_state=7))]).fit(X,y)
 reference=consultar(pipe,leer_json(consultas));guardar_json(folder/'referencia-antes.json',reference)
 model_path=folder/'modelo-entregas-v1.joblib';joblib.dump(pipe,model_path,compress=3)
 metadata=dict(version_artefacto='v1',origen='Configuración C1 elegida en M02-C08, reconstruida con sus 24 pedidos de desarrollo; no se reevalúa prueba ni se busca otra configuración.',features=FEATURES,unidades={'distancia_km':'kilómetros','pedidos_pendientes':'cantidad entera'},etiquetas={'0':'En plazo','1':'Retraso'},definicion_y='Retraso si minutos_reales>35',parametros={'max_depth':1,'min_samples_leaf':1,'random_state':7},filas_ajuste=len(rows),medianas=pipe.named_steps['preparar'].statistics_.tolist(),versiones=versiones(),sha256_modelo=sha(model_path),sha256_datos=sha(datos),integridad='Hash para detectar cambios accidentales; no autentica autor ni convierte un archivo desconocido en confiable.')
 guardar_json(folder/'metadata.json',metadata);guardar_json(folder/'comprobacion-proceso-a.json',dict(filas_ajuste=len(rows),consultas=len(reference),predicciones=[r['prediccion'] for r in reference],medianas=metadata['medianas'],versiones=metadata['versiones']))
 print('PROCESO A: ajuste con',len(rows),'de desarrollo; configuración C1 ya elegida en C08.')
 print('Guardado: modelo-entregas-v1.joblib + metadata.json + referencia-antes.json')
 print('Medianas:',metadata['medianas'],'| columnas:',FEATURES)
 print('Predicciones antes de guardar:',[r['categoria'] for r in reference])
 return metadata
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--datos',type=Path,default=Path(__file__).resolve().parent/'entrenamiento-desarrollo.csv');p.add_argument('--consultas',type=Path,default=Path(__file__).resolve().parent/'consultas.json');p.add_argument('--salida',type=Path,default=Path(__file__).resolve().parent/'artefactos');a=p.parse_args();entrenar(a.datos,a.consultas,a.salida)
