"""Contrato de entrada y versiones; sin entrenamiento ni acceso a etiquetas al consultar."""
import hashlib,json,math,platform
from pathlib import Path
import joblib,numpy as np,sklearn
FEATURES=['distancia_km','pedidos_pendientes'];NOMBRES={0:'En plazo',1:'Retraso'}
def versiones():return {'python':platform.python_version(),'numpy':np.__version__,'scikit-learn':sklearn.__version__,'joblib':joblib.__version__}
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def guardar_json(path,obj):Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def leer_json(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def validar_consultas(rows):
 if not isinstance(rows,list) or not rows:raise ValueError('La entrada debe ser una lista no vacía de consultas por nombre')
 ids=set();values=[]
 for r in rows:
  if not isinstance(r,dict) or set(r)!={'id',*FEATURES}:raise ValueError('Cada consulta debe contener solo id, distancia_km y pedidos_pendientes')
  if not isinstance(r['id'],str) or not r['id'].strip() or r['id'] in ids:raise ValueError('id debe ser texto no vacío y único')
  ids.add(r['id']);line=[]
  for key in FEATURES:
   v=r[key]
   if v is None:line.append(np.nan);continue
   if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0:raise ValueError(key+' debe ser número finito no negativo o null')
   if key=='pedidos_pendientes' and not float(v).is_integer():raise ValueError('pedidos_pendientes debe ser entero o null')
   line.append(float(v))
  values.append(line)
 return np.array(values,float)
def consultar(modelo,rows):
 X=validar_consultas(rows);pre=modelo.named_steps['preparar'];before=pre.statistics_.copy();prepared=pre.transform(X);pred=modelo.predict(X);assert np.array_equal(before,pre.statistics_)
 return [dict(id=r['id'],entrada={k:r[k] for k in FEATURES},transformada=a.tolist(),prediccion=int(p),categoria=NOMBRES[int(p)]) for r,a,p in zip(rows,prepared,pred)]
