"""Regresión de una entrada, partición fija y datos sintéticos."""
import csv,json
from pathlib import Path
import numpy as np
import sklearn
from sklearn.linear_model import LinearRegression
from sklearn.dummy import DummyRegressor
from sklearn.metrics import mean_absolute_error

DISTANCIAS=[1,1.5,2,2.5,3,3.5,4,4.5,5,5.5,6,6.5]
RUIDO=[-1,1,0,2,-2,0,1,-1,2,0,-2,0]
TRAIN=[dict(pedido=f'E{i+1:02}',grupo='entrenamiento',distancia_km=x,minutos_reales=12+5*x+e) for i,(x,e) in enumerate(zip(DISTANCIAS,RUIDO))]
TEST=[dict(pedido=f'P{i+1:02}',grupo='prueba',distancia_km=x,minutos_reales=y) for i,(x,y) in enumerate(zip([1.2,2.2,3.2,4.2,5.2,6.2],[19,24,30,36,38,55]))]
def ejecutar():
 X=np.array([[r['distancia_km']] for r in TRAIN]);y=np.array([r['minutos_reales'] for r in TRAIN]);Xt=np.array([[r['distancia_km']] for r in TEST]);yt=np.array([r['minutos_reales'] for r in TEST])
 model=LinearRegression().fit(X,y);baseline=DummyRegressor(strategy='mean').fit(X,y)
 pred=model.predict(Xt);reference=baseline.predict(Xt)
 cases=[dict(**r,prediccion=float(a),referencia=float(b),error_modelo=float(abs(a-r['minutos_reales'])),error_referencia=float(abs(b-r['minutos_reales']))) for r,a,b in zip(TEST,pred,reference)]
 result=dict(origen='Datos sintéticos nuevos, separados antes del ajuste',entrenamiento=TRAIN,prueba=TEST,casos=cases,coeficiente=float(model.coef_[0]),intercepto=float(model.intercept_),referencia_media=float(y.mean()),mae_modelo=float(mean_absolute_error(yt,pred)),mae_referencia=float(mean_absolute_error(yt,reference)),consulta=dict(distancia_km=4.1,prediccion=float(model.predict([[4.1]])[0])),fuera_de_rango=dict(distancia_km=10,prediccion=float(model.predict([[10]])[0])),rango_entrenamiento=[min(DISTANCIAS),max(DISTANCIAS)],version_sklearn=sklearn.__version__)
 return result,model,baseline
def exportar(folder):
 folder=Path(folder);folder.mkdir(exist_ok=True,parents=True);r,model,baseline=ejecutar()
 (folder/'resultados.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
 with (folder/'pedidos-regresion.csv').open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['pedido','grupo','distancia_km','minutos_reales']);w.writeheader();w.writerows(TRAIN+TEST)
 with (folder/'predicciones.csv').open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(r['casos'][0]));w.writeheader();w.writerows(r['casos'])
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,ax=plt.subplots(figsize=(10,6));ax.scatter(DISTANCIAS,[x['minutos_reales'] for x in TRAIN],label='Entrenamiento',color='#16b9ac');xx=np.linspace(1,6.5,100);ax.plot(xx,model.predict(xx.reshape(-1,1)),color='#7654cf',label='Recta ajustada');ax.scatter([x['distancia_km'] for x in TEST],[x['minutos_reales'] for x in TEST],marker='x',s=70,color='#c77e00',label='Prueba');ax.set_xlabel('Distancia (km)');ax.set_ylabel('Minutos reales / estimados');ax.legend();ax.set_title('Datos sintéticos · una sola entrada');fig.tight_layout();fig.savefig(folder/'recta-y-datos.png',dpi=160);plt.close(fig)
 print(f"12 entrenamiento | 6 prueba | referencia {r['referencia_media']:.2f} min")
 print(f"Recta: {r['intercepto']:.4f} + {r['coeficiente']:.4f} × distancia")
 print(f"MAE referencia: {r['mae_referencia']:.2f} | MAE modelo: {r['mae_modelo']:.2f} min")
 for x in r['casos']:print(f"{x['pedido']}: real {x['minutos_reales']:.0f} | predicción {x['prediccion']:.2f} | error {x['error_modelo']:.2f}")
 print(f"Consulta 4.1 km: {r['consulta']['prediccion']:.2f} min; sin resultado real para evaluar")
 return r
if __name__=='__main__':exportar(Path(__file__).resolve().parent)
