import json,math
from pathlib import Path
import numpy as np
from sklearn.metrics import mean_absolute_error
from practica import ejecutar,TRAIN,TEST
P=Path(__file__).resolve().parent
r,model,baseline=ejecutar();saved=json.loads((P/'resultados.json').read_text(encoding='utf-8'))
assert len(TRAIN)==12 and len(TEST)==6
assert set(x['pedido'] for x in TRAIN).isdisjoint(x['pedido'] for x in TEST)
assert model.n_features_in_==1
assert math.isclose(r['referencia_media'],sum(x['minutos_reales'] for x in TRAIN)/12)
assert math.isclose(r['mae_modelo'],sum(x['error_modelo'] for x in r['casos'])/6)
assert math.isclose(r['mae_referencia'],sum(x['error_referencia'] for x in r['casos'])/6)
assert r['mae_modelo']<r['mae_referencia'] and r['casos'][-1]['error_modelo']>12
# Refit from training alone; test labels cannot change the fitted parameters.
X=np.array([[x['distancia_km']] for x in TRAIN]);y=np.array([x['minutos_reales'] for x in TRAIN]);Xtest=np.array([[x['distancia_km']] for x in TEST])
from sklearn.linear_model import LinearRegression
other=LinearRegression().fit(X,y)
assert np.allclose(other.predict(Xtest),[x['prediccion'] for x in r['casos']])
assert math.isclose(float(model.predict([[4.1]])[0]),r['consulta']['prediccion'])
assert 1<=4.1<=6.5<10
for key in ['coeficiente','intercepto','mae_modelo','mae_referencia','referencia_media']:assert math.isclose(r[key],saved[key],rel_tol=1e-9)
print('OK: partición, ajuste solo con entrenamiento, referencia, MAE, consulta y fallo individual.')
