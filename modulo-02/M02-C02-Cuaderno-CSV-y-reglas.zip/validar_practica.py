import json,io
from pathlib import Path
import pandas as pd
from practica import analizar,CSV
P=Path(__file__).resolve().parent
raw,unique,clean,ready,review,unknown,r=analizar()
assert raw.shape==(12,5) and unique.shape==(11,5)
assert r['duplicados_exactos']==1
assert len(ready)==6 and len(review)==4 and len(unknown)==1
assert set(ready.pedido)|set(review.pedido)|set(unknown.pedido)==set(unique.pedido)
assert set(ready.pedido).isdisjoint(review.pedido) and set(ready.pedido).isdisjoint(unknown.pedido)
assert raw.equals(pd.read_csv(io.StringIO(CSV)))
assert r['faltantes_originales']=={'pedido':0,'distancia_km':1,'pedidos_pendientes':1,'lluvia':0,'minutos_reales':1}
assert review.set_index('pedido').loc['D08','distancia_km']==-2
assert ready.set_index('pedido').loc['D07','minutos_reales']==50
assert pd.isna(unknown.iloc[0]['minutos_reales'])
assert set(ready.lluvia)=={0,1} and pd.isna(review.set_index('pedido').loc['D11','lluvia'])
saved=json.loads((P/'resultados.json').read_text(encoding='utf-8'))
r.pop('version_pandas');saved.pop('version_pandas')
assert r==saved
print('OK: original intacto, duplicado exacto, categorías, tres rutas y casos conservados.')
