"""Datos sintéticos: explorar, separar problemas y documentar, sin entrenar."""
import io,json,unicodedata
from pathlib import Path
import pandas as pd

CSV='''pedido,distancia_km,pedidos_pendientes,lluvia,minutos_reales
D01,1.2,2,no,20
D02,2.0,3,No ,24
D03,,3,SI ,28
D04,3.5,5,no,32
D05,4.2,6,Sí,36
D06,5.0,7,si,40
D07,6.0,9,si,50
D08,-2.0,4,no,30
D09,2.5,,no,26
D10,3.0,4,no,
D02,2.0,3,No ,24
D11,4.0,6,desconocido,38
'''
def normalizar(value):
 return ''.join(c for c in unicodedata.normalize('NFD',str(value).strip().lower()) if not unicodedata.combining(c))
def analizar():
 original=pd.read_csv(io.StringIO(CSV))
 faltantes=original.isna().sum().astype(int).to_dict()
 unicos=original.drop_duplicates().copy()
 limpio=unicos.copy()
 limpio['lluvia']=limpio['lluvia'].map(normalizar).map({'si':1,'no':0})
 motivo=pd.Series('',index=limpio.index,dtype='str')
 reglas=[(limpio['distancia_km'].isna(),'distancia ausente'),(limpio['distancia_km']<0,'distancia negativa'),(limpio['pedidos_pendientes'].isna(),'cola ausente'),(limpio['lluvia'].isna(),'lluvia no reconocida')]
 for mask,label in reglas:motivo.loc[mask]=label
 ruta=pd.Series('listo',index=limpio.index,dtype='str')
 ruta.loc[limpio['minutos_reales'].isna()]='sin_etiqueta'
 ruta.loc[motivo!='']='revision'
 limpio['ruta']=ruta;limpio['motivo']=motivo
 listos=limpio.loc[ruta=='listo'].copy();revision=limpio.loc[ruta=='revision'].copy();sin_etiqueta=limpio.loc[ruta=='sin_etiqueta'].copy()
 report={'origen':'Datos inventados para la lección','filas_originales':len(original),'columnas':len(original.columns),'faltantes_originales':faltantes,'duplicados_exactos':int(original.duplicated().sum()),'filas_unicas':len(unicos),'listos':len(listos),'revision':len(revision),'sin_etiqueta':len(sin_etiqueta),'pedidos_listos':listos['pedido'].tolist(),'pedidos_revision':revision[['pedido','motivo']].to_dict(orient='records'),'sin_etiqueta_ids':sin_etiqueta['pedido'].tolist(),'maximo_conservado':int(listos['minutos_reales'].max()),'lluvia_antes':unicos['lluvia'].drop_duplicates().tolist(),'lluvia_despues':[0,1],'version_pandas':pd.__version__}
 return original,unicos,limpio,listos,revision,sin_etiqueta,report
def exportar(folder):
 folder=Path(folder);folder.mkdir(exist_ok=True,parents=True)
 original,unicos,limpio,listos,revision,sin_etiqueta,r=analizar()
 (folder/'pedidos-originales.csv').write_text(CSV,encoding='utf-8')
 for name,frame in [('pedidos-listos.csv',listos),('pedidos-revision.csv',revision),('pedidos-sin-etiqueta.csv',sin_etiqueta)]:frame.to_csv(folder/name,index=False)
 (folder/'resultados.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,ax=plt.subplots(figsize=(10,5));ax.bar(listos['pedido'],listos['minutos_reales'],color='#19bfae');ax.set_ylabel('Minutos reales');ax.set_title('Seis pedidos listos · datos sintéticos');ax.set_ylim(0,60);fig.tight_layout();fig.savefig(folder/'duraciones.png',dpi=180);plt.close(fig)
 print('Entrada: 12 filas, 5 columnas. Duplicado exacto: 1.')
 print('Después de quitar la copia: 11 pedidos únicos.')
 print('Ruta final: 6 listos | 4 para revisión | 1 sin etiqueta.')
 print('D07: 50 minutos. Se conserva; no hay evidencia de error.')
 return r
if __name__=='__main__':exportar(Path(__file__).resolve().parent)
