"""Contrato compartido, validación sin fugas y utilidades de integridad para M02-C12 (Proyecto integrador)."""
import hashlib
import json
import math
import sys
import joblib
import numpy as np
import sklearn
from pathlib import Path

FEATURES = ["usuarios_afectados", "minutos_sin_servicio"]
CLASES = {0: "En tiempo", 1: "Demora"}
VERSION_ARTEFACTO = "v1"


def leer_json(ruta: Path):
    return json.loads(Path(ruta).read_text(encoding="utf-8"))


def guardar_json(ruta: Path, datos):
    Path(ruta).write_text(json.dumps(datos, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def sha256_archivo(ruta: Path) -> str:
    return hashlib.sha256(Path(ruta).read_bytes()).hexdigest()


def versiones() -> dict:
    return {
        "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "numpy": np.__version__,
        "scikit_learn": sklearn.__version__,
        "joblib": joblib.__version__,
    }


def _validar_usuarios(valor):
    if valor is None or isinstance(valor, bool) or not isinstance(valor, (int, float)):
        raise ValueError("usuarios_afectados es obligatorio y debe ser un entero >= 1.")
    v = float(valor)
    if not math.isfinite(v) or v < 1 or not v.is_integer():
        raise ValueError("usuarios_afectados debe ser un entero >= 1 (sin decimales ni negativos).")
    return int(v)


def _validar_minutos(valor):
    if valor is None:
        return None
    if isinstance(valor, bool) or not isinstance(valor, (int, float)):
        raise ValueError("minutos_sin_servicio debe ser un número >= 0 o null.")
    v = float(valor)
    if not math.isfinite(v) or v < 0:
        raise ValueError("minutos_sin_servicio no puede ser negativo ni infinito.")
    return v


def validar_consulta(obj: dict, exigir_id: bool = False) -> dict:
    if not isinstance(obj, dict):
        raise ValueError("La consulta debe ser un objeto JSON con nombres de campo.")
    permitidas = set(FEATURES) | ({"id"} if exigir_id or "id" in obj else set())
    faltantes = set(FEATURES) - set(obj.keys())
    extras = set(obj.keys()) - permitidas
    if faltantes or extras:
        raise ValueError(f"Claves esperadas: {FEATURES}. Faltan={sorted(faltantes)} Extras={sorted(extras)}")
    limpio = {}
    if "id" in obj:
        cid = str(obj["id"]).strip()
        if not cid:
            raise ValueError("El identificador 'id' no puede estar vacío.")
        limpio["id"] = cid
    elif exigir_id:
        raise ValueError("Falta el identificador 'id'.")
    limpio["usuarios_afectados"] = _validar_usuarios(obj["usuarios_afectados"])
    limpio["minutos_sin_servicio"] = _validar_minutos(obj["minutos_sin_servicio"])
    return limpio


def fila_a_matriz(consulta_limpia: dict) -> np.ndarray:
    fila = [
        np.nan if consulta_limpia[col] is None else float(consulta_limpia[col])
        for col in FEATURES
    ]
    return np.array([fila], dtype=float)


def verificar_metadata(carpeta_modelo: Path) -> tuple[dict, Path]:
    carpeta = Path(carpeta_modelo)
    meta_path = carpeta / "metadata.json"
    if not meta_path.exists():
        raise FileNotFoundError("No existe metadata.json. Ejecuta primero python entrenar_proyecto.py.")
    meta = leer_json(meta_path)
    if meta.get("version_artefacto") != VERSION_ARTEFACTO:
        raise ValueError(f"Versión incompatible: {meta.get('version_artefacto')}")
    if meta.get("features") != FEATURES:
        raise ValueError(f"Columnas inesperadas en metadata: {meta.get('features')}")
    actual = versiones()
    if meta.get("versiones") != actual:
        raise ValueError(f"Versiones del entorno cambiaron ({actual} vs {meta.get('versiones')}). Regenera con entrenar_proyecto.py.")
    modelo_path = carpeta / meta["archivo_modelo"]
    if not modelo_path.exists():
        raise FileNotFoundError(f"Falta el archivo de modelo {modelo_path.name}.")
    if sha256_archivo(modelo_path) != meta.get("sha256_modelo"):
        raise ValueError("La huella SHA-256 del artefacto no coincide con metadata.json.")
    return meta, modelo_path
