"""Entrena con validación cruzada sin fuga, evalúa 1 sola vez la prueba sellada y persiste el artefacto (M02-C12)."""
import argparse
import csv
import joblib
import numpy as np
from pathlib import Path
from sklearn.dummy import DummyClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeClassifier

import comun

ROOT = Path(__file__).resolve().parent


def cargar_csv_etiquetado(ruta: Path):
    with Path(ruta).open(encoding="utf-8", newline="") as f:
        r = csv.DictReader(f)
        esperadas = ["id", *comun.FEATURES, "demora"]
        if r.fieldnames != esperadas:
            raise ValueError(f"Columnas inesperadas en {ruta.name}: {r.fieldnames}")
        ids, filas_x, y = [], [], []
        vistos = set()
        for row in r:
            limpio = comun.validar_consulta(
                {
                    "id": row["id"],
                    "usuarios_afectados": None if not row["usuarios_afectados"].strip() else int(row["usuarios_afectados"]),
                    "minutos_sin_servicio": None if not row["minutos_sin_servicio"].strip() else float(row["minutos_sin_servicio"]),
                },
                exigir_id=True,
            )
            if limpio["id"] in vistos:
                raise ValueError(f"ID duplicado: {limpio['id']}")
            vistos.add(limpio["id"])
            etiqueta = int(row["demora"])
            if etiqueta not in (0, 1):
                raise ValueError(f"Etiqueta inválida: {etiqueta}")
            ids.append(limpio["id"])
            filas_x.append([np.nan if limpio[c] is None else float(limpio[c]) for c in comun.FEATURES])
            y.append(etiqueta)
    return ids, np.array(filas_x, dtype=float), np.array(y, dtype=int)


def crear_pipeline(estimador) -> Pipeline:
    return Pipeline(
        [
            ("preparar", SimpleImputer(strategy="median", add_indicator=True)),
            ("modelo", estimador),
        ]
    )


def entrenar_y_evaluar(carpeta_salida: Path) -> dict:
    carpeta = Path(carpeta_salida)
    carpeta.mkdir(parents=True, exist_ok=True)

    dev_path = ROOT / "datos-desarrollo.csv"
    test_path = ROOT / "datos-prueba-sellada.csv"
    _, X_dev, y_dev = cargar_csv_etiquetado(dev_path)

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=7)

    candidatos = [
        ("B0", "Dummy más frecuente (línea base)", DummyClassifier(strategy="most_frequent"), (99, 0)),
        ("C1", "Árbol profundidad 1 · hoja mín. 2", DecisionTreeClassifier(max_depth=1, min_samples_leaf=2, random_state=7), (1, -2)),
        ("C2", "Árbol profundidad 2 · hoja mín. 2", DecisionTreeClassifier(max_depth=2, min_samples_leaf=2, random_state=7), (2, -2)),
        ("C3", "Árbol profundidad 6 · hoja mín. 1", DecisionTreeClassifier(max_depth=6, min_samples_leaf=1, random_state=7), (6, -1)),
    ]

    tabla_cv = []
    for codigo, nombre, est, complejidad in candidatos:
        pipe = crear_pipeline(est)
        puntajes = cross_val_score(pipe, X_dev, y_dev, cv=cv, scoring="accuracy")
        pipe.fit(X_dev, y_dev)
        acc_train = float(accuracy_score(y_dev, pipe.predict(X_dev)))
        tabla_cv.append(
            {
                "codigo": codigo,
                "nombre": nombre,
                "cv_media": float(np.mean(puntajes)),
                "cv_pliegues": [float(s) for s in puntajes],
                "train_aparente": acc_train,
                "complejidad": complejidad,
            }
        )

    # Regla explícita de selección: mayor cv_media entre árboles candidatos (C1..C3); desempate por menor complejidad
    solo_modelos = [c for c in tabla_cv if c["codigo"] != "B0"]
    ganador_info = sorted(solo_modelos, key=lambda r: (-round(r["cv_media"], 10), r["complejidad"]))[0]
    ganador_codigo = ganador_info["codigo"]
    est_ganador = {c[0]: c[2] for c in candidatos}[ganador_codigo]

    # Ajuste único final sobre las 30 filas de desarrollo
    pipeline_final = crear_pipeline(est_ganador)
    pipeline_final.fit(X_dev, y_dev)
    medianas = [float(m) for m in pipeline_final.named_steps["preparar"].statistics_]

    # Línea base ajustada en desarrollo para comparar en la apertura única de prueba sellada
    pipe_base = crear_pipeline(DummyClassifier(strategy="most_frequent"))
    pipe_base.fit(X_dev, y_dev)

    # Apertura ÚNICA de datos-prueba-sellada.csv (10 filas, sin volver a tocar hiperparámetros)
    ids_test, X_test, y_test = cargar_csv_etiquetado(test_path)
    pred_test = pipeline_final.predict(X_test)
    pred_base_test = pipe_base.predict(X_test)
    acc_test = float(accuracy_score(y_test, pred_test))
    acc_base_test = float(accuracy_score(y_test, pred_base_test))
    tn, fp, fn, tp = [int(v) for v in confusion_matrix(y_test, pred_test, labels=[0, 1]).ravel()]

    archivo_modelo = f"modelo-soporte-{comun.VERSION_ARTEFACTO}.joblib"
    ruta_modelo = carpeta / archivo_modelo
    joblib.dump(pipeline_final, ruta_modelo, compress=3)
    huella_modelo = comun.sha256_archivo(ruta_modelo)

    # Referencia antes de cerrar proceso de entrenamiento para verificar reproducción 4/4
    consultas_ref = comun.leer_json(ROOT / "consultas.json")
    referencia_antes = []
    for q in consultas_ref:
        limpio = comun.validar_consulta(q, exigir_id=True)
        X_q = comun.fila_a_matriz(limpio)
        transf = [float(v) for v in pipeline_final.named_steps["preparar"].transform(X_q)[0]]
        pred = int(pipeline_final.predict(X_q)[0])
        referencia_antes.append(
            {
                "id": limpio["id"],
                "entrada": {k: limpio[k] for k in comun.FEATURES},
                "transformada": transf,
                "prediccion": pred,
                "categoria": comun.CLASES[pred],
            }
        )

    metadata = {
        "proyecto": "M02-C12 · Tickets de soporte técnico",
        "version_artefacto": comun.VERSION_ARTEFACTO,
        "archivo_modelo": archivo_modelo,
        "sha256_modelo": huella_modelo,
        "sha256_desarrollo": comun.sha256_archivo(dev_path),
        "sha256_prueba_sellada": comun.sha256_archivo(test_path),
        "features": comun.FEATURES,
        "clases": {str(k): v for k, v in comun.CLASES.items()},
        "filas_desarrollo": int(len(y_dev)),
        "filas_prueba_sellada": int(len(y_test)),
        "candidato_elegido": ganador_codigo,
        "descripcion_candidato": ganador_info["nombre"],
        "medianas": medianas,
        "tabla_cv": [
            {k: v for k, v in item.items() if k != "complejidad"}
            for item in tabla_cv
        ],
        "prueba_sellada_unica": {
            "aperturas": 1,
            "exactitud_modelo": acc_test,
            "aciertos_modelo": int(round(acc_test * len(y_test))),
            "total_prueba": int(len(y_test)),
            "exactitud_base": acc_base_test,
            "aciertos_base": int(round(acc_base_test * len(y_test))),
            "matriz_confusion": {"tn": tn, "fp": fp, "fn": fn, "tp": tp},
            "detalle_filas": [
                {"id": cid, "real": int(yr), "predicho": int(yp)}
                for cid, yr, yp in zip(ids_test, y_test, pred_test)
            ],
        },
        "versiones": comun.versiones(),
        "aviso_seguridad": "Carga únicamente artefactos generados por ti o de origen confiable verificado.",
    }

    comun.guardar_json(carpeta / "metadata.json", metadata)
    comun.guardar_json(carpeta / "referencia-antes.json", referencia_antes)
    print(f"GANADOR CV: {ganador_codigo} ({ganador_info['cv_media']*100:.1f}%) | PRUEBA SELLADA (1 vez): {int(round(acc_test*len(y_test)))}/{len(y_test)} ({acc_test*100:.1f}%) vs base {int(round(acc_base_test*len(y_test)))}/{len(y_test)}")
    print(f"MEDIANAS APRENDIDAS: {medianas} | MATRIZ CONFUSIÓN [TN,FP,FN,TP]: {[tn, fp, fn, tp]}")
    return metadata


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--salida", type=Path, default=ROOT / "artefactos")
    args = p.parse_args()
    entrenar_y_evaluar(args.salida)
