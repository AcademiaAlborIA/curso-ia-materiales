"""Verificación integral de las 6 etapas del Proyecto Integrador M02-C12."""
import json
import shutil
import subprocess
import sys
import tempfile
import threading
import urllib.error
import urllib.request
from pathlib import Path
from sklearn.impute import SimpleImputer
from sklearn.tree import DecisionTreeClassifier

import comun
from app import crear_servidor
from entrenar_proyecto import entrenar_y_evaluar
from monitor_proyecto import comparar_con_referencia, ejecutar_suite_monitoreo

ROOT = Path(__file__).resolve().parent


def post_json(url: str, carga: dict) -> tuple[int, dict]:
    req = urllib.request.Request(
        url + "/predecir",
        data=json.dumps(carga).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req) as r:
            return r.status, json.load(r)
    except urllib.error.HTTPError as e:
        return e.code, json.load(e)


def verificar_recarga_aislada(carpeta_modelo: Path, consultas_path: Path):
    """Comprueba en un subproceso limpio sin CSV históricos que el artefacto reproduce 4/4 consultas."""
    with tempfile.TemporaryDirectory() as tmp:
        tdir = Path(tmp)
        shutil.copy2(ROOT / "comun.py", tdir / "comun.py")
        shutil.copy2(consultas_path, tdir / "consultas.json")
        shutil.copytree(carpeta_modelo, tdir / "artefactos")
        codigo = """
import joblib, json
from pathlib import Path
import comun
meta, mpath = comun.verificar_metadata(Path("artefactos"))
pipe = joblib.load(mpath)
antes = comun.leer_json(Path("artefactos/referencia-antes.json"))
qs = comun.leer_json(Path("consultas.json"))
salidas = []
for q in qs:
    limpio = comun.validar_consulta(q, exigir_id=True)
    X = comun.fila_a_matriz(limpio)
    tr = [float(v) for v in pipe.named_steps["preparar"].transform(X)[0]]
    pr = int(pipe.predict(X)[0])
    salidas.append({"id": limpio["id"], "entrada": {k: limpio[k] for k in comun.FEATURES}, "transformada": tr, "prediccion": pr, "categoria": comun.CLASES[pr]})
assert salidas == antes, f"Diferencia al recargar: {salidas} vs {antes}"
print(json.dumps({"reproducidas": len(salidas)}))
"""
        r = subprocess.run([sys.executable, "-c", codigo], cwd=tdir, capture_output=True, text=True, encoding="utf-8")
        if r.returncode != 0:
            raise AssertionError(f"Fallo en recarga aislada: {r.stderr}")
        return json.loads(r.stdout.strip())


def main():
    carpeta_art = ROOT / "artefactos"
    meta = entrenar_y_evaluar(carpeta_art)

    # 1. Validación cruzada y selección sin fuga
    tabla = {c["codigo"]: c for c in meta["tabla_cv"]}
    assert meta["candidato_elegido"] == "C2", f"Se esperaba C2 como ganador y salió {meta['candidato_elegido']}"
    assert round(tabla["B0"]["cv_media"], 3) == 0.500
    assert tabla["C2"]["cv_media"] > tabla["C1"]["cv_media"]
    assert tabla["C2"]["cv_media"] > tabla["C3"]["cv_media"]
    assert tabla["C3"]["train_aparente"] == 1.0  # sobreajuste demostrado

    # 2. Apertura única de prueba sellada (9/10 vs 5/10)
    ps = meta["prueba_sellada_unica"]
    assert ps["aperturas"] == 1
    assert ps["aciertos_modelo"] == 9 and ps["total_prueba"] == 10
    assert ps["aciertos_base"] == 5
    assert ps["matriz_confusion"] == {"tn": 5, "fp": 0, "fn": 1, "tp": 4}
    assert meta["medianas"] == [6.0, 13.5]

    # 3. Persistencia y reproducción 4/4 en proceso separado sin CSV
    recarga = verificar_recarga_aislada(carpeta_art, ROOT / "consultas.json")
    assert recarga["reproducidas"] == 4

    # 4. Integración HTTP real con métodos fit bloqueados
    ruta_joblib = carpeta_art / meta["archivo_modelo"]
    huella_antes = comun.sha256_archivo(ruta_joblib)

    orig_imp_fit = SimpleImputer.fit
    orig_tree_fit = DecisionTreeClassifier.fit

    def prohibido(*_a, **_kw):
        raise AssertionError("PROHIBIDO: la aplicación no debe llamar a fit durante las consultas.")

    SimpleImputer.fit = prohibido
    DecisionTreeClassifier.fit = prohibido
    evidencias_http = []
    srv = crear_servidor(carpeta_art, puerto=0)
    hilo = threading.Thread(target=srv.serve_forever, daemon=True)
    hilo.start()
    url = f"http://127.0.0.1:{srv.server_port}"
    try:
        with urllib.request.urlopen(url) as resp:
            html = resp.read().decode("utf-8")
            assert "Priorización orientativa de tickets de soporte" in html

        casos_validos = [
            ("Q01", 2, 5, "En tiempo", [2.0, 5.0, 0.0]),
            ("Q02", 18, 45, "Demora", [18.0, 45.0, 0.0]),
            ("Q03", 14, None, "Demora", [14.0, 13.5, 1.0]),
            ("Q04", 5, 48, "Demora", [5.0, 48.0, 0.0]),
        ]
        for cid, u, m, cat_esp, tr_esp in casos_validos:
            codigo, r = post_json(url, {"id": cid, "usuarios_afectados": u, "minutos_sin_servicio": m})
            assert codigo == 200 and r["categoria"] == cat_esp and r["transformada"] == tr_esp, f"Fallo en {cid}: {r}"
            evidencias_http.append({"id": cid, "http": codigo, **r})

        conteo_validas = srv.servicio.predicciones
        casos_invalidos = [
            ("NEG_USUARIOS", -3, 15),
            ("FRAC_USUARIOS", 2.5, 10),
            ("TEXTO", "diez", 15),
            ("MINUTOS_NEG", 4, -5),
        ]
        for cid, u, m in casos_invalidos:
            codigo, r = post_json(url, {"id": cid, "usuarios_afectados": u, "minutos_sin_servicio": m})
            assert codigo == 400 and "error" in r and "categoria" not in r, f"Rechazo mal manejado en {cid}: {r}"
            evidencias_http.append({"id": cid, "http": codigo, **r})

        assert srv.servicio.cargas == 1
        assert srv.servicio.predicciones == conteo_validas == 4
        assert comun.sha256_archivo(ruta_joblib) == huella_antes
        assert srv.servicio.pipe.named_steps["preparar"].statistics_.tolist() == [6.0, 13.5]
    finally:
        srv.shutdown()
        srv.server_close()
        SimpleImputer.fit = orig_imp_fit
        DecisionTreeClassifier.fit = orig_tree_fit

    # 5. Monitoreo descriptivo sobre Semana 1, Semana 2 y Muestra corta
    mon = ejecutar_suite_monitoreo(ROOT / "informes-monitoreo")
    c1 = mon["control_semana_1"]
    s2 = mon["lote_semana_2"]
    mc = mon["muestra_corta"]

    assert c1["cambios_pp"] == {"ausentes_pp": 0.0, "mas30_pp": 0.0}
    assert c1["evaluacion_reglas"] == {"alerta_ausentes": False, "alerta_mas30": False}

    assert s2["lote"]["recibidas"] == 27 and s2["lote"]["validas"] == 25 and s2["lote"]["rechazadas_total"] == 2
    assert s2["cambios_pp"] == {"ausentes_pp": 28.0, "mas30_pp": 67.95}
    assert s2["evaluacion_reglas"] == {"alerta_ausentes": True, "alerta_mas30": True}
    assert s2["exactitud_real"] is None

    assert mc["evaluacion_reglas"] == {"alerta_ausentes": None, "alerta_mas30": None}

    # Comprobación del reto práctico mi-lote.csv (cambiar S03 de 34 min a 8 min -> intervalos [2, 1, 10])
    with tempfile.TemporaryDirectory() as tmp_m:
        mi_lote = Path(tmp_m) / "mi-lote.csv"
        lineas = (ROOT / "lote-semana-2.csv").read_text(encoding="utf-8").splitlines()
        nuevas = ["S03,12,8" if ln.startswith("S03,") else ln for ln in lineas]
        mi_lote.write_text("\n".join(nuevas) + "\n", encoding="utf-8")
        rep_mi = comparar_con_referencia(ROOT / "referencia.csv", mi_lote, ROOT / "reglas-monitoreo.json")
        assert rep_mi["lote"]["intervalos_0_10_30_mas"] == [2, 1, 10]
        assert round(rep_mi["lote"]["pct_mas30"], 1) == 76.9

    comun.guardar_json(ROOT / "resultados-http.json", evidencias_http)
    resumen_verif = {
        "cv_sin_fuga": True,
        "ganador_cv": "C2",
        "prueba_sellada_unica": "9/10 (90,0 %) vs base 5/10 (50,0 %)",
        "recarga_aislada_4_de_4": True,
        "http_real_validas": 4,
        "http_real_rechazadas": 4,
        "cargas_servidor": 1,
        "fit_bloqueado_en_inferencia": True,
        "modelo_y_medianas_intactos": True,
        "monitoreo_semana_2_verificado": True,
    }
    comun.guardar_json(ROOT / "verificacion-practica.json", resumen_verif)
    print("PROYECTO INTEGRADOR M02-C12 VERIFICADO DE EXTREMO A EXTREMO OK.")


if __name__ == "__main__":
    main()
