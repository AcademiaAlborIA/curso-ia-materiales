const form = document.getElementById("formulario");
const inpUsuarios = document.getElementById("usuarios");
const inpMinutos = document.getElementById("minutos");
const chkAusente = document.getElementById("minutosAusente");
const btn = document.getElementById("botonConsultar");

const estadoPendiente = document.getElementById("estadoPendiente");
const cajaError = document.getElementById("cajaError");
const textoError = document.getElementById("textoError");
const cajaResultado = document.getElementById("cajaResultado");
const pastillaCategoria = document.getElementById("pastillaCategoria");
const jsonEntrada = document.getElementById("jsonEntrada");
const filaTransformada = document.getElementById("filaTransformada");
const medianasFijas = document.getElementById("medianasFijas");
const avisoLimite = document.getElementById("avisoLimite");

let revision = 0;
let huboResultado = false;

function limpiarSalidaPorEdicion() {
  revision += 1;
  cajaError.classList.add("oculto");
  cajaResultado.classList.add("oculto");
  estadoPendiente.classList.remove("oculto");
  if (huboResultado) {
    estadoPendiente.innerHTML = "Datos modificados · la respuesta anterior se ocultó. Pulsa <strong>Consultar prioridad</strong>.";
  }
}

function convertirCampo(texto) {
  const limpio = texto.trim().replace(",", ".");
  if (limpio === "") return undefined;
  const num = Number(limpio);
  return Number.isNaN(num) ? texto.trim() : num;
}

inpUsuarios.addEventListener("input", limpiarSalidaPorEdicion);
inpMinutos.addEventListener("input", limpiarSalidaPorEdicion);

chkAusente.addEventListener("change", () => {
  if (chkAusente.checked) {
    inpMinutos.value = "";
    inpMinutos.disabled = true;
  } else {
    inpMinutos.disabled = false;
  }
  limpiarSalidaPorEdicion();
});

form.addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const miRevision = ++revision;

  const uVal = convertirCampo(inpUsuarios.value);
  if (uVal === undefined) {
    huboResultado = true;
    estadoPendiente.classList.add("oculto");
    cajaResultado.classList.add("oculto");
    textoError.textContent = "Completa 'Usuarios afectados' antes de consultar.";
    cajaError.classList.remove("oculto");
    return;
  }

  let mVal = null;
  if (!chkAusente.checked) {
    const parsedM = convertirCampo(inpMinutos.value);
    if (parsedM === undefined) {
      huboResultado = true;
      estadoPendiente.classList.add("oculto");
      cajaResultado.classList.add("oculto");
      textoError.textContent = "Escribe 'Minutos sin servicio' o marca explícitamente la casilla de no disponible.";
      cajaError.classList.remove("oculto");
      return;
    }
    mVal = parsedM;
  }

  btn.disabled = true;
  estadoPendiente.textContent = "Consultando servidor Python local...";
  estadoPendiente.classList.remove("oculto");
  cajaError.classList.add("oculto");
  cajaResultado.classList.add("oculto");

  try {
    const resp = await fetch("/predecir", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        usuarios_afectados: uVal,
        minutos_sin_servicio: mVal,
      }),
    });
    const datos = await resp.json();
    if (miRevision !== revision) return;
    huboResultado = true;
    estadoPendiente.classList.add("oculto");

    if (!resp.ok) {
      textoError.textContent = datos.error || "Consulta rechazada por validación en Python.";
      cajaError.classList.remove("oculto");
      return;
    }

    pastillaCategoria.textContent = datos.categoria;
    pastillaCategoria.className = "pastilla " + (datos.prediccion === 1 ? "pastilla-demora" : "pastilla-ok");
    jsonEntrada.textContent = JSON.stringify(datos.entrada);
    filaTransformada.textContent = "[ " + datos.transformada.join(" , ") + " ]";
    medianasFijas.textContent = "[ " + datos.medianas_aprendidas.join(" , ") + " ]";
    avisoLimite.textContent = datos.aviso;
    cajaResultado.classList.remove("oculto");
  } catch (err) {
    if (miRevision !== revision) return;
    huboResultado = true;
    estadoPendiente.classList.add("oculto");
    textoError.textContent = "No se pudo conectar con python app.py. Verifica que la terminal siga activa.";
    cajaError.classList.remove("oculto");
  } finally {
    if (miRevision === revision) {
      btn.disabled = false;
    }
  }
});
