"""Servidor HTTP local de predicción orientativa para M02-C12 (carga 1 vez, predict sin fit)."""
import argparse
import json
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import joblib
import comun

ROOT = Path(__file__).resolve().parent


class ServicioPrediccion:
    def __init__(self, carpeta_modelo: Path):
        self.lock = threading.Lock()
        self.cargas = 0
        self.predicciones = 0
        self.meta, self.modelo_path = comun.verificar_metadata(carpeta_modelo)
        self.pipe = joblib.load(self.modelo_path)
        self.cargas += 1

    def predecir(self, carga_json: dict) -> dict:
        limpio = comun.validar_consulta(carga_json, exigir_id=False)
        X = comun.fila_a_matriz(limpio)
        transf = [float(v) for v in self.pipe.named_steps["preparar"].transform(X)[0]]
        pred = int(self.pipe.predict(X)[0])
        with self.lock:
            self.predicciones += 1
            total_pred = self.predicciones
        return {
            "prediccion": pred,
            "categoria": comun.CLASES[pred],
            "entrada": {k: limpio[k] for k in comun.FEATURES},
            "transformada": transf,
            "medianas_aprendidas": self.meta["medianas"],
            "candidato": self.meta["candidato_elegido"],
            "predicciones_acumuladas": total_pred,
            "aviso": "Estimación orientativa local (Demora = > 4 h al entrenar). No garantiza tiempos reales ni sustituye revisión humana.",
        }


def crear_servidor(carpeta_modelo: Path, puerto: int = 8770) -> ThreadingHTTPServer:
    servicio = ServicioPrediccion(carpeta_modelo)
    estaticos = {
        "/": ("index.html", "text/html; charset=utf-8"),
        "/index.html": ("index.html", "text/html; charset=utf-8"),
        "/estilo.css": ("estilo.css", "text/css; charset=utf-8"),
        "/app.js": ("app.js", "application/javascript; charset=utf-8"),
    }

    class Manejador(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            return

        def _enviar_json(self, codigo: int, obj: dict):
            cuerpo = json.dumps(obj, ensure_ascii=False, allow_nan=False).encode("utf-8")
            self.send_response(codigo)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(cuerpo)

        def do_GET(self):
            ruta = self.path.split("?", 1)[0]
            if ruta == "/estado":
                self._enviar_json(
                    HTTPStatus.OK,
                    {
                        "cargas": servicio.cargas,
                        "predicciones": servicio.predicciones,
                        "candidato": servicio.meta["candidato_elegido"],
                        "medianas": servicio.meta["medianas"],
                        "version_artefacto": servicio.meta["version_artefacto"],
                    },
                )
                return
            if ruta not in estaticos:
                self._enviar_json(HTTPStatus.NOT_FOUND, {"error": "Ruta no encontrada."})
                return
            archivo, mime = estaticos[ruta]
            contenido = (ROOT / archivo).read_bytes()
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(contenido)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(contenido)

        def do_POST(self):
            ruta = self.path.split("?", 1)[0]
            if ruta != "/predecir":
                self._enviar_json(HTTPStatus.NOT_FOUND, {"error": "Usa POST /predecir."})
                return
            try:
                largo = int(self.headers.get("Content-Length", "0"))
                if largo <= 0 or largo > 16384:
                    raise ValueError("Cuerpo JSON vacío o demasiado grande.")
                bruto = self.rfile.read(largo).decode("utf-8")
                datos = json.loads(bruto)
                respuesta = servicio.predecir(datos)
                self._enviar_json(HTTPStatus.OK, respuesta)
            except Exception as exc:
                self._enviar_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})

    servidor = ThreadingHTTPServer(("127.0.0.1", puerto), Manejador)
    servidor.servicio = servicio
    return servidor


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--modelo", type=Path, default=ROOT / "artefactos")
    p.add_argument("--puerto", type=int, default=8770)
    args = p.parse_args()
    srv = crear_servidor(args.modelo, args.puerto)
    print(f"APP INTEGRADORA LISTA en http://127.0.0.1:{srv.server_port} (Ctrl+C para cerrar)", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido correctamente.")
    finally:
        srv.server_close()


if __name__ == "__main__":
    main()
