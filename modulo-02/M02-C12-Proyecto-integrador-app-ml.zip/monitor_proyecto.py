"""Monitoreo descriptivo de lotes nuevos sin etiquetas frente a referencia.csv (M02-C12)."""
import argparse
import csv
import math
from pathlib import Path
import comun

ROOT = Path(__file__).resolve().parent


def parsear_celda_num(txt: str, entero_estricto: bool = False):
    s = txt.strip()
    if s == "":
        return None
    v = float(s)
    if not math.isfinite(v):
        raise ValueError("Valor no finito.")
    if entero_estricto:
        if not v.is_integer():
            raise ValueError("Debe ser un número entero sin decimales.")
        return int(v)
    return v


def resumir_lote_csv(ruta: Path) -> dict:
    ruta = Path(ruta)
    with ruta.open(encoding="utf-8", newline="") as f:
        r = csv.DictReader(f)
        esperadas = ["id", *comun.FEATURES]
        if r.fieldnames != esperadas:
            raise ValueError(f"Columnas inesperadas en {ruta.name}: {r.fieldnames} (se esperaba {esperadas})")
        recibidas = 0
        validas = []
        rechazadas = []
        vistos = set()
        for row in r:
            recibidas += 1
            cid = (row.get("id") or "").strip() or f"FILA-{recibidas}"
            if cid in vistos:
                rechazadas.append({"id": cid, "motivo": "Identificador duplicado"})
                continue
            vistos.add(cid)
            try:
                u_val = parsear_celda_num(row["usuarios_afectados"], entero_estricto=True)
                m_val = parsear_celda_num(row["minutos_sin_servicio"], entero_estricto=False)
                limpio = comun.validar_consulta(
                    {"id": cid, "usuarios_afectados": u_val, "minutos_sin_servicio": m_val},
                    exigir_id=True,
                )
                validas.append(limpio)
            except Exception as exc:
                rechazadas.append({"id": cid, "motivo": str(exc)})

    n_validas = len(validas)
    n_ausentes = sum(1 for x in validas if x["minutos_sin_servicio"] is None)
    observados = [float(x["minutos_sin_servicio"]) for x in validas if x["minutos_sin_servicio"] is not None]
    n_obs = len(observados)
    intervalos = [
        sum(1 for m in observados if 0.0 <= m <= 10.0),
        sum(1 for m in observados if 10.0 < m <= 30.0),
        sum(1 for m in observados if m > 30.0),
    ]
    pct_ausentes = round(100.0 * n_ausentes / n_validas, 2) if n_validas > 0 else None
    pct_mas30 = round(100.0 * intervalos[2] / n_obs, 2) if n_obs > 0 else None

    return {
        "archivo": ruta.name,
        "sha256": comun.sha256_archivo(ruta),
        "recibidas": recibidas,
        "validas": n_validas,
        "rechazadas_total": len(rechazadas),
        "rechazadas": rechazadas,
        "ausentes_minutos": n_ausentes,
        "pct_ausentes": pct_ausentes,
        "observados_minutos": n_obs,
        "intervalos_0_10_30_mas": intervalos,
        "pct_mas30": pct_mas30,
    }


def comparar_con_referencia(ruta_ref: Path, ruta_lote: Path, ruta_reglas: Path) -> dict:
    ref = resumir_lote_csv(ruta_ref)
    if ref["rechazadas_total"] != 0:
        raise ValueError("referencia.csv no debe contener filas inválidas.")
    lote = resumir_lote_csv(ruta_lote)
    reglas = comun.leer_json(ruta_reglas)

    min_val = int(reglas["minimo_filas_validas"])
    min_obs = int(reglas["minimo_minutos_observados"])
    umbral_aus = float(reglas["cambio_ausentes_pp"])
    umbral_m30 = float(reglas["cambio_mas30_pp"])

    suficiente_val = ref["validas"] >= min_val and lote["validas"] >= min_val
    suficiente_obs = ref["observados_minutos"] >= min_obs and lote["observados_minutos"] >= min_obs

    diff_aus_pp = round(lote["pct_ausentes"] - ref["pct_ausentes"], 2) if (ref["pct_ausentes"] is not None and lote["pct_ausentes"] is not None) else None
    diff_m30_pp = round(lote["pct_mas30"] - ref["pct_mas30"], 2) if (ref["pct_mas30"] is not None and lote["pct_mas30"] is not None) else None

    alerta_ausentes = bool(abs(diff_aus_pp) > umbral_aus) if suficiente_val else None
    alerta_mas30 = bool(abs(diff_m30_pp) > umbral_m30) if suficiente_obs else None

    if alerta_ausentes is None or alerta_mas30 is None:
        estado = "Muestra insuficiente: regla no evaluada"
        accion = "Reunir un lote con tamaño suficiente antes de aplicar umbrales; no marcar falso verde."
    elif alerta_ausentes or alerta_mas30:
        estado = "Señal descriptiva en entradas: investigar origen"
        accion = "Revisar captura de minutos_sin_servicio y tipos de incidencia antes de culpar al modelo o reentrenar."
    else:
        estado = "Sin señal en estas 2 reglas descriptivas"
        accion = "Conservar referencia.csv intacta y evaluar exactitud solo cuando existan desenlaces reales."

    return {
        "referencia": ref,
        "lote": lote,
        "reglas": reglas,
        "cambios_pp": {
            "ausentes_pp": diff_aus_pp,
            "mas30_pp": diff_m30_pp,
        },
        "evaluacion_reglas": {
            "alerta_ausentes": alerta_ausentes,
            "alerta_mas30": alerta_mas30,
        },
        "exactitud_real": None,
        "estado": estado,
        "accion_recomendada": accion,
    }


def ejecutar_suite_monitoreo(carpeta_salida: Path) -> dict:
    salida = Path(carpeta_salida)
    salida.mkdir(parents=True, exist_ok=True)
    ref_p = ROOT / "referencia.csv"
    reg_p = ROOT / "reglas-monitoreo.json"
    casos = {
        "control_semana_1": comparar_con_referencia(ref_p, ROOT / "control-semana-1.csv", reg_p),
        "lote_semana_2": comparar_con_referencia(ref_p, ROOT / "lote-semana-2.csv", reg_p),
        "muestra_corta": comparar_con_referencia(ref_p, ROOT / "muestra-corta.csv", reg_p),
    }
    comun.guardar_json(salida / "resumen-monitoreo.json", casos)
    s2 = casos["lote_semana_2"]
    print(
        f"MONITOREO OK | Semana 2: {s2['lote']['recibidas']} recibidas = {s2['lote']['validas']} válidas + {s2['lote']['rechazadas_total']} rechazadas | "
        f"Ausentes: {s2['referencia']['pct_ausentes']}% -> {s2['lote']['pct_ausentes']}% ({s2['cambios_pp']['ausentes_pp']:+.1f} pp) | "
        f">30 min: {s2['referencia']['pct_mas30']}% -> {s2['lote']['pct_mas30']}% ({s2['cambios_pp']['mas30_pp']:+.1f} pp)"
    )
    return casos


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--referencia", type=Path, default=ROOT / "referencia.csv")
    p.add_argument("--lote", type=Path, default=None)
    p.add_argument("--reglas", type=Path, default=ROOT / "reglas-monitoreo.json")
    p.add_argument("--salida", type=Path, default=ROOT / "informes-monitoreo")
    args = p.parse_args()
    if args.lote is not None:
        args.salida.mkdir(parents=True, exist_ok=True)
        rep = comparar_con_referencia(args.referencia, args.lote, args.reglas)
        comun.guardar_json(args.salida / f"informe-{args.lote.stem}.json", rep)
        print(f"Informe guardado en {args.salida / f'informe-{args.lote.stem}.json'}: {rep['estado']}")
    else:
        ejecutar_suite_monitoreo(args.salida)
